<?php
session_start();
require 'db.php';

// Check if user is logged in
if (!isset($_SESSION['customer_id'])) {
    header("Location: customer_auth.php");
    exit;
}

$user_id = $_SESSION['customer_id'];
$name = $_SESSION['customer_name'];

// Fetch their bookings
$stmt = $pdo->prepare("SELECT b.*, s.name as service_name FROM bookings b JOIN services s ON b.service_id = s.id WHERE b.user_id = ? ORDER BY b.booking_date DESC, b.start_time DESC");
$stmt->execute([$user_id]);
$bookings = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Account | Bella Vista Oasis Spa</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/png" href="logo.png">
    <style>
        /* Page-specific styling for the Account Dashboard */
        .account-wrapper {
            max-width: 1000px;
            margin: 140px auto 80px auto; /* Pushes content below fixed header */
            padding: 0 20px;
        }
        .welcome-header {
            text-align: center;
            margin-bottom: 50px;
        }
        .welcome-header h1 {
            font-size: 42px;
            color: #3B2A20;
            margin-bottom: 10px;
        }
        .welcome-header p {
            color: #6F4E37;
            font-size: 18px;
        }
        .booking-card {
            background: #F3E9DA;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 20px;
            border: 1px solid #D9BFA3;
            box-shadow: 0 5px 15px rgba(59, 42, 32, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
            transition: transform 0.3s ease;
        }
        .booking-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(59, 42, 32, 0.1);
        }
        .booking-info h3 {
            color: #3B2A20;
            font-size: 22px;
            margin-bottom: 5px;
        }
        .booking-info p {
            color: #6F4E37;
            font-size: 15px;
            margin-bottom: 5px;
        }
        .booking-info strong {
            color: #45270E;
        }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            background: #FBF7F0;
            border-radius: 15px;
            border: 1px dashed #D9BFA3;
        }
        .empty-state h3 {
            font-size: 24px;
            color: #3B2A20;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <!-- NAVBAR -->
    <nav style="background-color: #3B2A20; position: fixed; top: 0; width: 100%; z-index: 1000; border-bottom: 1px solid #D9BFA3;">
        <div class="logo">
            <a href="index.php" style="text-decoration:none; color: #FBF7F0; display:flex; align-items:center; font-family: 'Cormorant Garamond', serif; font-size: 26px; font-weight: 700;">
                <img src="logo.png" alt="Logo" style="width: 40px; height: 40px; object-fit: contain; margin-right: 10px;"> 
                Bella Vista Oasis Spa
            </a>
        </div>
        <div class="nav-links">
            <a href="index.php" style="color: #FBF7F0;">Home</a>
            <a href="booking.php" class="btn" style="background: #6F4E37; color: #fff !important;">Book Appointment</a>
            <a href="logout.php" onclick="return confirm('Are you sure you want to log out?');" style="color: #D9BFA3; margin-left: 15px;">Logout</a>
        </div>
    </nav>

    <!-- MAIN CONTENT -->
    <div class="account-wrapper">
        
        <div class="welcome-header">
            <h1>Welcome, <?= htmlspecialchars($name) ?></h1>
            <p>Manage your upcoming appointments and view your booking history.</p>
        </div>

        <h2 style="color: #3B2A20; font-size: 28px; margin-bottom: 25px; border-bottom: 2px solid #D9BFA3; padding-bottom: 10px;">Your Bookings</h2>

        <?php if(empty($bookings)): ?>
            <div class="empty-state">
                <h3>You have no bookings yet.</h3>
                <p style="color: #6F4E37; margin-bottom: 20px;">Ready for a relaxing session? Book your first appointment today.</p>
                <a href="booking.php" class="btn">Book Now</a>
            </div>
        <?php else: ?>
            <?php foreach($bookings as $b): ?>
                <div class="booking-card">
                    <div class="booking-info">
                        <h3><?= htmlspecialchars($b['service_name']) ?></h3>
                        <p><strong>Ref:</strong> <?= $b['reference_no'] ?></p>
                        <p><strong>Massage:</strong> <?= htmlspecialchars($b['massage_details']) ?></p>
                    </div>

                    <div class="booking-info">
                        <p><strong>Date:</strong> <?= date('F d, Y', strtotime($b['booking_date'])) ?></p>
                        <p><strong>Time:</strong> <?= date('g:i A', strtotime($b['start_time'])) ?> - <?= date('g:i A', strtotime($b['end_time'])) ?></p>
                        <p><strong>Total:</strong> ₱<?= number_format($b['total_price'], 2) ?></p>
                    </div>

                    <div>
                        <?php 
                            // Simple status check based on date
                            $is_past = strtotime($b['booking_date']) < strtotime(date('Y-m-d'));
                            if ($is_past) {
                                echo '<span style="background: #6F4E37; color: #fff; padding: 8px 15px; border-radius: 20px; font-size: 13px; font-weight: 500;">Completed</span>';
                            } else {
                                echo '<span style="background: #A9744F; color: #fff; padding: 8px 15px; border-radius: 20px; font-size: 13px; font-weight: 500;">Upcoming</span>';
                            }
                        ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

    </div>
</body>
</html>