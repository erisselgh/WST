<?php
session_start();
// Check if customer is logged in
$is_logged_in = isset($_SESSION['customer_id']);
$customer_name = $_SESSION['customer_name'] ?? '';
require 'db.php';

$step = 1; 
$message = "";

// Initialize variables for the confirmation screen
$final_ref = "";
$final_total = 0;
$final_massage = "";

// Fetch rooms
$stmt = $pdo->query("SELECT * FROM services");
$rooms = $stmt->fetchAll();

// Handle Step 1 Submission (Selecting Rooms & Massages)
if (isset($_POST['select_service'])) {
    $_SESSION['booking_service_id'] = $_POST['service_id'];
    $_SESSION['booking_date'] = $_POST['date'];
    
    // THIS IS THE FIX: We only use the standard dropdown 'time' now.
    $_SESSION['booking_time'] = $_POST['time']; 
    
    $_SESSION['booking_guests'] = $_POST['guests'];
    $_SESSION['massage_details'] = isset($_POST['massage_details']) ? $_POST['massage_details'] : 'None selected';
    $_SESSION['grand_total'] = $_POST['grand_total'];
    
    // SAVE THE DURATION HERE
    $_SESSION['booking_duration'] = $_POST['total_duration']; 
    
    header("Location: booking.php");
    exit;
}

// Handle Step 2 Submission (Confirming Details)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_booking'])) {
    $service_id = $_SESSION['booking_service_id'];
    $date = $_SESSION['booking_date'];
    $time = $_SESSION['booking_time'];
    $guests = (int)$_SESSION['booking_guests'];
    $name = $_POST['name'];
    $mobile = $_POST['mobile'];
    $massage_details = $_SESSION['massage_details'];
    $total_price = $_SESSION['grand_total']; 

    $start_time = strtotime($time);
    
    // Use the calculated duration from Step 1 (in seconds)
    $duration_seconds = $_SESSION['booking_duration'] * 60; 
    $end_time = date('H:i:s', $start_time + $duration_seconds);
    $ref = 'BV-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);

    $user_id = $_SESSION['customer_id'] ?? NULL;

    $sql = "INSERT INTO bookings (reference_no, user_id, service_id, booking_date, start_time, end_time, guests, total_price, guest_name, mobile, massage_details) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    
    if ($stmt->execute([$ref, $user_id, $service_id, $date, $time, $end_time, $guests, $total_price, $name, $mobile, $massage_details])) {
        
        // CLEAR SESSION
        unset($_SESSION['booking_service_id'], $_SESSION['booking_date'], $_SESSION['booking_time'], $_SESSION['booking_guests'], $_SESSION['massage_details'], $_SESSION['grand_total']);
        
        // PRG PATTERN: Redirect immediately
        header("Location: booking.php?success=1&ref=" . urlencode($ref) . "&total=" . urlencode($total_price) . "&massage=" . urlencode($massage_details));
        exit;
    }
}

// Check which step to show
if (isset($_GET['success'])) {
    $step = 3;
    $final_ref = htmlspecialchars($_GET['ref'] ?? '');
    $final_total = (float)($_GET['total'] ?? 0);
    $final_massage = htmlspecialchars($_GET['massage'] ?? '');
} elseif (isset($_SESSION['booking_service_id'])) {
    $step = 2;
}

// Reset Logic
if(isset($_GET['reset'])) {
    unset($_SESSION['booking_service_id'], $_SESSION['booking_date'], $_SESSION['booking_time'], $_SESSION['booking_guests'], $_SESSION['massage_details'], $_SESSION['grand_total']);
    header("Location: booking.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Book Appointment - Bella Vista Oasis Spa</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/png" href="logo.png">
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;600;700&family=Jost:wght@300;400;500;700&display=swap" rel="stylesheet">
    <style>
        .home-btn {
            background: #6F4E37 !important;
            color: #FBF7F0 !important;
            padding: 10px 20px;
            border-radius: 25px;
            text-decoration: none;
            transition: background 0.3s ease;
        }

        .home-btn:hover {
            background: #D9BFA3 !important;
        }
        
        body {
            position: relative;
            background-color: #262524;
            z-index: 0;
            margin: 0;
        }

        body::before {
            content: "";
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            background-image: url('booking_bg.png');  
            background-size: cover;
            background-position: center;
            opacity: 100%; 
        }

        nav {
            background-color: #3B2A20 !important;
            position: fixed !important;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000 !important;
            padding: 20px 50px;
            display: flex;
            align-items: center;
            border-bottom: 1px solid #D9BFA3;
        }

        .step-container { 
            max-width: 900px; 
            margin: 120px auto 50px auto; 
            background: radial-gradient(circle, #F9E8C9 0%, #D8A45F 100%); 
            padding: 40px; 
            border-radius: 20px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }

        .service-option { 
            display: block; 
            padding: 20px; 
            background: #f5e5cf; 
            border: 1px solid #D9BFA3; 
            border-radius: 10px; 
            margin-bottom: 15px; 
            cursor: pointer; 
            transition: all 0.3s; 
        }
        
        input[type="radio"]:checked + .service-option { 
            border-color: #6F4E37; 
            background: #f5e5cf; 
            box-shadow: 0 0 0 2px #6F4E37; 
        }
        
        .hidden-radio { 
            display: none; 
        }
        
        .massage-grid { 
            display: grid; 
            grid-template-columns: 1fr; 
            gap: 10px; 
            background: #f5e5cf; 
            padding: 20px; 
            border-radius: 10px; 
            border: 1px solid #D9BFA3; 
        }
        
        .massage-item { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            padding: 10px; 
            border-bottom: 1px solid #F3E9DA; 
        }
        
        .massage-item:last-child { 
            border-bottom: none; 
        }
        
        .massage-checkbox { 
            display: flex; 
            align-items: center; 
            gap: 10px; 
            cursor: pointer; 
        }
        
        .massage-checkbox input[type="checkbox"] { 
            width: 20px; 
            height: 20px; 
            accent-color: #6F4E37; 
            cursor: pointer; 
        }
        
        .massage-label strong { 
            font-size: 15px; 
            color: #3B2A20; 
            display: block; 
        }
        
        .duration-select { 
            padding: 8px; 
            border-radius: 5px; 
            border: 1px solid #D9BFA3; 
            font-family: 'Jost', sans-serif; 
            color: #3B2A20; 
            cursor: pointer; 
            background: #f5e5cf; 
        }
        
        .summary-box { 
            background: #3d281c; 
            color: #FBF7F0; 
            padding: 20px; 
            border-radius: 10px; 
            margin-top: 20px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            font-size: 20px; 
        }

        .form-group input[type="text"], 
        .form-group input[type="number"], 
        .form-group input[type="email"] {
            width: 100%; 
            padding: 12px; 
            border: 1px solid #D9BFA3; 
            border-radius: 8px; 
            background: #f5e5cf;
            font-family: 'Jost', sans-serif; 
            color: #3B2A20;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logo">
            <a href="index.php" style="text-decoration:none; color: #FBF7F0; display:flex; align-items:center; font-family: 'Cormorant Garamond', serif; font-size: 26px; font-weight: 700;">
                <img src="logo.png" alt="Logo" style="width: 40px; height: 40px; object-fit: contain; margin-right: 10px;"> 
                Bella Vista Oasis Spa
            </a>
        </div>
        <div>
            <a href="index.php" class="btn home-btn">Back to Home</a>
        </div>
    </nav>

    <div class="step-container">
        <!-- STEP 1: SELECT ROOM & MASSAGES -->
        <?php if($step === 1): ?>
            <h2 style="text-align: center; margin-bottom: 10px; font-weight: bold;">Select Room & Treatments</h2>
            <p style="text-align: center; color: #6F4E37; margin-bottom: 30px; font-weight: bold;">Customize your spa experience.</p>
            
            <form method="POST" id="bookingForm">
                <h4 style="margin-bottom: 15px; font-weight: bold; color: #45270E; font-size: x-large;">Choose a Room</h4>
                <?php foreach($rooms as $r): ?>
                    <label>
                        <input type="radio" name="service_id" value="<?= $r['id'] ?>" class="hidden-radio" data-price="<?= $r['price'] ?>" onchange="calculateTotal()" required>
                        <div class="service-option">
                            <div style="display:flex; justify-content:space-between; align-items:center;">
                                <strong><?= $r['name'] ?> (Max <?= $r['max_capacity'] ?> guests)</strong>
                                <span style="color: #6F4E37; font-weight: 500;">₱<?= number_format($r['price'], 2) ?></span>
                            </div>
                        </div>
                    </label>
                <?php endforeach; ?>

                <h4 style="margin: 30px 0 15px 0; font-size: x-large; font-weight: bold;">Add Massages (Select duration)</h4>
                
                <div class="massage-grid">
                    <!-- Swedish -->
                    <div class="massage-item">
                        <label class="massage-checkbox">
                            <input type="checkbox" name="massage[]" value="Swedish" data-price-1="800" data-price-2="1500" onchange="calculateTotal()">
                            <div class="massage-label"><strong>Swedish</strong></div>
                        </label>
                        <select class="duration-select" onchange="calculateTotal()">
                            <option value="1">1 hour (₱800)</option>
                            <option value="2">2 hours (₱1,500)</option>
                        </select>
                    </div>

                    <!-- Foot Reflexology -->
                    <div class="massage-item">
                        <label class="massage-checkbox">
                            <input type="checkbox" name="massage[]" value="Foot Reflexology" data-price-1="800" data-price-2="1500" onchange="calculateTotal()">
                            <div class="massage-label"><strong>Foot Reflexology</strong></div>
                        </label>
                        <select class="duration-select" onchange="calculateTotal()">
                            <option value="1">1 hour (₱800)</option>
                            <option value="2">2 hours (₱1,500)</option>
                        </select>
                    </div>

                    <!-- Shiatsu -->
                    <div class="massage-item">
                        <label class="massage-checkbox">
                            <input type="checkbox" name="massage[]" value="Shiatsu" data-price-1="900" data-price-2="1700" onchange="calculateTotal()">
                            <div class="massage-label"><strong>Shiatsu</strong></div>
                        </label>
                        <select class="duration-select" onchange="calculateTotal()">
                            <option value="1">1 hour (₱900)</option>
                            <option value="2">2 hours (₱1,700)</option>
                        </select>
                    </div>

                    <!-- Hilot -->
                    <div class="massage-item">
                        <label class="massage-checkbox">
                            <input type="checkbox" name="massage[]" value="Hilot" data-price-1="1000" data-price-2="1900" onchange="calculateTotal()">
                            <div class="massage-label"><strong>Hilot (Filipino)</strong></div>
                        </label>
                        <select class="duration-select" onchange="calculateTotal()">
                            <option value="1">1 hour (₱1,000)</option>
                            <option value="2">2 hours (₱1,900)</option>
                        </select>
                    </div>

                    <!-- Aromatherapy -->
                    <div class="massage-item">
                        <label class="massage-checkbox">
                            <input type="checkbox" name="massage[]" value="Aromatherapy" data-price-1="1000" data-price-2="1900" onchange="calculateTotal()">
                            <div class="massage-label"><strong>Aromatherapy</strong></div>
                        </label>
                        <select class="duration-select" onchange="calculateTotal()">
                            <option value="1">1 hour (₱1,000)</option>
                            <option value="2">2 hours (₱1,900)</option>
                        </select>
                    </div>

                    <!-- Deep Tissue -->
                    <div class="massage-item">
                        <label class="massage-checkbox">
                            <input type="checkbox" name="massage[]" value="Deep Tissue" data-price-1="1100" data-price-2="2100" onchange="calculateTotal()">
                            <div class="massage-label"><strong>Deep Tissue</strong></div>
                        </label>
                        <select class="duration-select" onchange="calculateTotal()">
                            <option value="1">1 hour (₱1,100)</option>
                            <option value="2">2 hours (₱2,100)</option>
                        </select>
                    </div>

                    <!-- Hot Stone -->
                    <div class="massage-item">
                        <label class="massage-checkbox">
                            <input type="checkbox" name="massage[]" value="Hot Stone" data-price-1="1300" data-price-2="2500" onchange="calculateTotal()">
                            <div class="massage-label"><strong>Hot Stone</strong></div>
                        </label>
                        <select class="duration-select" onchange="calculateTotal()">
                            <option value="1">1 hour (₱1,300)</option>
                            <option value="2">2 hours (₱2,500)</option>
                        </select>
                    </div>
                </div>

                <h4 style="margin: 30px 0 15px 0; font-size: x-large; font-weight: bolder;">Date & Time</h4>
                <div class="grid-2">
                    <div class="form-group">
                        <label style="color: #45270E; font-weight: 500; font-weight: bold;">Date</label>
                        <input type="date" name="date" required min="<?= date('Y-m-d') ?>" style="background-color: #f5e5cf; color: #3B2A20; border: 1px solid #D9BFA3; padding: 12px; border-radius: 8px; width: 100%; font-family: 'Jost', sans-serif;">
                    </div>

                    <div class="form-group">
                        <label style="color: #45270E; font-weight: 500; font-weight: bold;">Start time</label>
                        <select name="time" required style="width: 100%; padding: 12px; border: 1px solid #D9BFA3; border-radius: 8px; background: #f5e5cf; font-family: 'Jost', sans-serif;">
                            <option value="">Select a time...</option>
                            <?php
                            for ($hour = 10; $hour <= 21; $hour++) {
                                foreach (['00', '30'] as $minute) {
                                    if ($hour == 21 && $minute == '30') continue; 
                                    $time24 = sprintf("%02d:%s", $hour, $minute);
                                    $time12 = date("g:i A", strtotime($time24));
                                    echo "<option value='$time24'>$time12</option>";
                                }
                            }
                            ?>
                        </select>
                    </div>       
                </div>
                <div class="form-group">
                    <label style="font-family: 'Jost', sans-serif; font-size: 16px; font-weight: 700; color: #45270E; margin-bottom: 8px; display: block;">Number of Guests (Max 6)</label>
                    <input type="number" name="guests" id="guestInput" min="1" max="6" value="1" required oninput="calculateTotal()" style="background-color: #f5e5cf; color: #3B2A20; border: 1px solid #D9BFA3; padding: 12px; border-radius: 8px; width: 100%; font-family: 'Jost', sans-serif; font-size: 16px;">
                </div>

                <input type="hidden" name="massage_details" id="massage_details_input" value="None selected">
                <input type="hidden" name="grand_total" id="grand_total_input" value="0">
                <input type="hidden" name="total_duration" id="total_duration_input" value="60">

                <div class="summary-box" style="display: flex; flex-direction: column; gap: 10px;">
                    <div style="font-family: 'Jost', sans-serif; font-size: 16px; font-weight: 700;display: flex; justify-content: space-between; width: 100%;">
                        <span>Estimated Total:</span>
                        <strong id="display_total">₱0.00</strong>
                    </div>
                    <div style="font-family: 'Jost', sans-serif; font-size: 16px; font-weight: 700; color: #FBF7F0;display: flex; justify-content: space-between; width: 100%;">
                        <span>Total Session Time:</span>
                        <span id="display_duration">0 hours</span>
                    </div>
                </div>
                
                <!-- BUTTONS CONTAINER -->
                <div style="display: flex; gap: 15px; margin-top: 20px; align-items: center;">
                    <a href="index.php?reset=1" style="flex: 1; text-align: center; padding: 12px; border: 1px solid #3d281c; border-radius: 25px; color: #3d281c; text-decoration: none; font-weight: 500; transition: all 0.3s; background: transparent;" onmouseover="this.style.background='#6F4E37'; this.style.color='#FBF7F0';" onmouseout="this.style.background='transparent'; this.style.color='#6F4E37';">
                        Cancel
                    </a>
                    <button type="submit" name="select_service" class="btn" style="flex: 2; margin: 0; padding: 12px; background-color: #3d281c !important; font-size:large">
                        Next
                    </button>
                </div>
            </form>
            
            <script>
                function calculateTotal() {
                    let roomPrice = 0;
                    let roomId = null;
                    
                    let radios = document.getElementsByName('service_id');
                    for (let i = 0; i < radios.length; i++) {
                        if (radios[i].checked) { 
                            roomPrice = parseFloat(radios[i].getAttribute('data-price')); 
                            roomId = radios[i].value; 
                            break;
                        }
                    }

                    let massageTotal = 0;
                    let totalDurationMinutes = 0; 
                    let selectedNames = [];
                    
                    let items = document.querySelectorAll('.massage-item');
                    for (let i = 0; i < items.length; i++) {
                        let item = items[i];
                        let cb = item.querySelector('input[type="checkbox"]');
                        
                        if (cb.checked) {
                            let durationSelect = item.querySelector('select');
                            let durationHours = parseInt(durationSelect.value); 
                            totalDurationMinutes += (durationHours * 60);
                            let priceAttr = (durationHours === 1) ? 'data-price-1' : 'data-price-2';
                            let price = parseFloat(cb.getAttribute(priceAttr));
                            massageTotal += price;
                            selectedNames.push(cb.value + " (" + durationHours + " hr)");
                        }
                    }

                    let extraFee = 0;
                    let guestInput = document.getElementById('guestInput');
                    let guests = parseInt(guestInput.value) || 1;
                    
                    if (guests > 6) { 
                        guests = 6; 
                        guestInput.value = 6; 
                    }
                    if (roomId == "3" && guests > 4) { 
                        extraFee = (guests - 4) * 750; 
                    }

                    let grandTotal = roomPrice + massageTotal + extraFee;

                    document.getElementById('display_total').innerText = '₱' + grandTotal.toFixed(2);
                    document.getElementById('grand_total_input').value = grandTotal;
                    document.getElementById('massage_details_input').value = selectedNames.length > 0 ? selectedNames.join(', ') : 'None selected';
                    
                    if (totalDurationMinutes === 0) {
                        totalDurationMinutes = 60;
                    }
                    
                    document.getElementById('total_duration_input').value = totalDurationMinutes;
                    
                    let durationHoursDisplay = totalDurationMinutes / 60;
                    document.getElementById('display_duration').innerText = durationHoursDisplay + ' hour(s)';
                }

                window.onload = calculateTotal;
            </script>

        <!-- STEP 2: ENTER DETAILS -->
        <?php elseif($step === 2): ?>
            <?php 
                $durationMins = $_SESSION['booking_duration'] ?? 60; 
                $hours = floor($durationMins / 60);
                $mins = $durationMins % 60;
                $durationText = ($hours > 0 ? $hours . " hr " : "") . ($mins > 0 ? $mins . " mins" : "");
                if($hours == 0 && $mins == 0) $durationText = "1 hr";
            ?>

            <div style="background: #f5e5cf; padding: 20px; border-radius: 10px; margin-bottom: 30px; border: 1px solid #D9BFA3;">
                <div style="display:flex; justify-content:space-between; margin-bottom: 10px;">
                    <span style="font-size: 12px; color: #45270E; font-weight: bold; text-transform: uppercase;">Your Selection</span>
                    <a href="booking.php?reset=1" style="font-size: 13px; color: #5C3E19; text-decoration: underline;">Change</a>
                </div>
                
                <p style="font-size: 16px; margin-bottom: 5px; color: #5C3E19;"><strong style="color: #45270E;">Massages:</strong> <?= htmlspecialchars($_SESSION['massage_details']) ?></p>
                
                <p style="font-size: 16px; color: #5C3E19; margin-bottom: 15px;"><strong style="color: #45270E;">Date:</strong> <?= date('M d, Y', strtotime($_SESSION['booking_date'])) ?> at <?= date('g:i A', strtotime($_SESSION['booking_time'])) ?></p>
                
                <div style="border-top: 1px solid #D9BFA3; padding-top: 15px;">
                    <h3 style="color: #45270E; margin-bottom: 5px;">Total Amount: <span style="color: #5C3E19; font-family: 'Jost', sans-serif; font-weight: normal; font-size: 18px;">₱<?= number_format($_SESSION['grand_total'], 2) ?></span></h3>
                    <p style="font-size: 16px; color: #5C3E19;"><strong style="color: #45270E;">Total Session Time:</strong> <?= $durationText ?></p>
                </div>
            </div>

            <form method="POST" onsubmit="return confirmBooking();">
                <h4 style="margin-bottom: 15px; color: #45270E; font-weight: 700;">Health Declaration</h4>
                
                <div class="form-group" style="display: grid; grid-template-columns: auto auto auto auto 1fr; gap: 20px; align-items: center; margin-bottom: 30px; color: #5C3E19;">
                    <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; white-space: nowrap;">
                        <input type="checkbox" name="health[]" value="Medical condition"> Medical condition
                    </label>
                    <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; white-space: nowrap;">
                        <input type="checkbox" name="health[]" value="Recent injury"> Recent injury
                    </label>
                    <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; white-space: nowrap;">
                        <input type="checkbox" name="health[]" value="Pregnancy"> Pregnancy
                    </label>
                    <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; white-space: nowrap;">
                        <input type="checkbox" name="health[]" value="None" id="noneHealthCheck" onchange="toggleNoneHealth()"> None
                    </label>
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; white-space: nowrap;">
                            <input type="checkbox" id="otherHealthCheck" onchange="toggleOtherHealth()"> Others:
                        </label>
                        <input type="text" name="health[]" id="otherHealthInput" placeholder="Please specify..." pattern="[A-Za-z\s]+" title="Letters and spaces only." style="display:none; padding: 8px 12px; border: 1px solid #D9BFA3; border-radius: 5px; font-family: 'Jost', sans-serif; font-size: 14px; width: 100%; max-width: 200px; background: #FBF7F0; color: #5C3E19;">
                    </div>
                </div>

                <h4 style="margin-bottom: 15px; color: #45270E; font-weight: 700;">Contact Information</h4>

                <div class="grid-2">
                    <div class="form-group">
                        <label style="color: #45270E; font-weight: bold;">Full Name</label>
                        <input type="text" name="name" required placeholder="e.g. Jane Doe" pattern="[A-Za-z\s\.\-]+" title="Please enter a valid name (letters only, no numbers)." style="color: #5C3E19; background: #f5e5cf;">
                    </div>
                    <div class="form-group">
                        <label style="color: #45270E; font-weight: bold;">Mobile Number</label>
                        <input type="text" name="mobile" required placeholder="09123456789" pattern="09[0-9]{9}" title="Please enter a valid 11-digit mobile number starting with 09." maxlength="11" style="color: #5C3E19; background: #f5e5cf;">
                    </div>
                </div>
                <button type="submit" name="confirm_booking" class="btn" style="width: 100%; margin-top: 20px; background: #3B2A20;">Confirm Booking</button>
            </form>

        <!-- STEP 3: CONFIRMATION -->
        <?php elseif($step === 3): ?>
            <div style="text-align: center; padding: 20px;">
                <h2 style="color: #6F4E37; margin-bottom: 10px;">Booking Confirmed!</h2>
                <p style="margin-bottom: 20px;">Thank you for choosing Bella Vista Oasis Spa.</p>
                
                <div style="background: #3B2A20; color: #FBF7F0; padding: 30px; border-radius: 15px; margin: 20px auto; max-width: 400px;">
                    <p style="font-size: 14px; color: #D9BFA3; text-transform: uppercase; letter-spacing: 1px;">Your Reference Code</p>
                    <h1 style="font-size: 36px; margin: 10px 0;"><?= $final_ref ?></h1>
                    <p style="font-size: 18px;">Total: ₱<?= number_format($final_total, 2) ?></p>
                    <p style="font-size: 14px; color: #D9BFA3; margin-top: 10px;"><?= $final_massage ?></p>
                </div>
                
                <p style="font-size: 14px; color: #6F4E37; margin-bottom: 30px;">Please save this reference code. You will need it to manage or cancel your booking.</p>
                <a href="booking.php" class="btn">Book another appointment</a>
            </div>
            
            <script>
                if (window.history.replaceState) {
                    window.history.replaceState(null, null, window.location.pathname);
                }
            </script>
        <?php endif; ?>
    </div>

    <script>
        function toggleOtherHealth() {
            let otherCheck = document.getElementById('otherHealthCheck');
            let otherInput = document.getElementById('otherHealthInput');
            let noneCheck = document.getElementById('noneHealthCheck');
            
            if (otherCheck.checked) {
                otherInput.style.display = 'block';
                otherInput.focus();
                otherInput.required = true;
                noneCheck.checked = false;
            } else {
                otherInput.style.display = 'none';
                otherInput.value = '';
                otherInput.required = false;
            }
        }

        function toggleNoneHealth() {
            let noneCheck = document.getElementById('noneHealthCheck');
            let otherCheck = document.getElementById('otherHealthCheck');
            let otherInput = document.getElementById('otherHealthInput');
            
            let specificHealthChecks = document.querySelectorAll('input[name="health[]"]:not(#noneHealthCheck):not(#otherHealthCheck)');
            
            if (noneCheck.checked) {
                specificHealthChecks.forEach(box => {
                    box.checked = false;
                });
                otherCheck.checked = false;
                otherInput.style.display = 'none';
                otherInput.value = '';
                otherInput.required = false;
            }
        }

        document.addEventListener("DOMContentLoaded", function() {
            let noneCheck = document.getElementById('noneHealthCheck');
            let specificHealthChecks = document.querySelectorAll('input[name="health[]"]:not(#noneHealthCheck):not(#otherHealthCheck)');
            
            specificHealthChecks.forEach(box => {
                box.addEventListener('change', function() {
                    if (this.checked) {
                        noneCheck.checked = false;
                    }
                });
            });
        });

        function confirmBooking() {
            return confirm("Confirm Booking?\n\nClick OK to finalize your appointment.");
        }
    </script>
</body>
</html>