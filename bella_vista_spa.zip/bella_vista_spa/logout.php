<?php
session_start();
session_unset();
session_destroy();

// Redirect to the CUSTOMER login page
header("Location: customer_auth.php");
exit;
?>