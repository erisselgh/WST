<?php
session_start();
require 'db.php';

$booking = null;
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ref = strtoupper(trim($_POST['reference']));
    $mobile = trim($_POST['mobile']);
    
    $stmt = $pdo->prepare("SELECT b.*, s.name as service_name FROM bookings b JOIN services s ON b.service_id = s.id WHERE b.reference_no = ? AND b.mobile = ?");
    $stmt->execute([$ref, $mobile]);
    $booking = $stmt->fetch();
    
    if (!$booking) {
        $error = "No booking found matching that reference number and mobile number.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Find My Booking | Bella Vista</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/png" href="logo.png">
    <style>
        /* --- MODAL STYLES --- */
        .modal-overlay {
            display: <?= $booking ? 'flex' : 'none'; ?>; /* Shows automatically if booking is found */
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6); /* Darkened background */
            backdrop-filter: blur(5px); /* Slight blur effect */
            z-index: 2000;
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background: #3B2A20;
            color: #FBF7F0;
            padding: 40px;
            border-radius: 15px;
            width: 90%;
            max-width: 450px;
            box-shadow: 0 15px 40px rgba(0,0,0,0.3);
            position: relative;
            animation: popIn 0.3s ease-out;
        }

        @keyframes popIn {
            from { transform: scale(0.9); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }

        .close-btn {
            position: absolute;
            top: 15px;
            right: 20px;
            color: #A9744F;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            line-height: 1;
        }

        .close-btn:hover {
            color: #FBF7F0;
        }
        /* --- PAGE BACKGROUND & HEADER FIX --- */
        body {
            position: relative;
            background-color: #FBF7F0;
            z-index: 0;
            margin: 0;
            padding: 0;
            padding-top: 90px; /* Pushes content below the fixed header */
        }

        /* Adds the background image with low transparency */
        body::before {
            content: "";
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            background-image: url('booking_bg.png'); 
            background-size: cover;
            background-position: center;
            opacity: 100%; 
        }
    </style>
</head>
<body>
    
    <nav style="background-color: #3B2A20; position: fixed; top: 0; width: 100%; z-index: 1000; border-bottom: 1px solid #D9BFA3;">
        <div class="logo">
            <a href="index.php" style="text-decoration:none; color: #FBF7F0; display:flex; align-items:center; font-family: 'Cormorant Garamond', serif; font-size: 26px; font-weight: 700;">
                <img src="logo.png" alt="Logo" style="width: 40px; height: 40px; object-fit: contain; margin-right: 10px;"> 
                Bella Vista Oasis Spa
            </a>
        </div>
        <div class="nav-links">
            <a href="index.php" class="btn" style="background: #FBF7F0; color: #3B2A20 !important;">Back to Home</a>
        </div>
    </nav>

    <!-- MAIN FORM CARD -->
    <div style="max-width: 600px; margin: 140px auto 80px auto; background: radial-gradient(circle, #F9E8C9 0%, #D8A45F 100%); padding: 40px; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.1);">
        <h2 style="text-align: center; margin-bottom: 10px; color: #3B2A20;">Find my booking</h2>
        <p style="text-align: center; color: #6F4E37; margin-bottom: 30px;">For guests: view your reservation without an account.</p>

        <?php if($error): ?>
            <div style="background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin-bottom: 20px; font-size: 14px; border: 1px solid #f5c6cb; text-align: center;">
                <?= $error ?>
            </div>
        <?php endif; ?>

        <form method="POST" style="background: #FBF7F0; padding: 30px; border-radius: 10px; border: 1px solid #D9BFA3;">
            <div class="form-group">
                <label style="color: #45270E; font-weight: 500;">Booking Reference</label>
                <input type="text" name="reference" required placeholder="e.g. BV-1234" style="background: #f5e5cf; border: 1px solid #D9BFA3; color: #3B2A20; padding: 12px; width: 100%; border-radius: 8px;">
            </div>
            <div class="form-group">
                <label style="color: #45270E; font-weight: 500;">Mobile number used when booking</label>
                <input type="text" name="mobile" required placeholder="09123456789" style="background: #f5e5cf; border: 1px solid #D9BFA3; color: #3B2A20; padding: 12px; width: 100%; border-radius: 8px;">
            </div>
            <button type="submit" class="btn" style="width: 100%;">Find booking</button>
        </form>
    </div>

    <!-- POPUP MODAL (Only shows if booking is found) -->
    <?php if($booking): ?>
    <div class="modal-overlay" id="bookingModal">
        <div class="modal-content">
            <!-- Close Button -->
            <span class="close-btn" onclick="closeModal()">&times;</span>
            
            <h3 style="color: #A9744F; margin-bottom: 20px; font-size: 24px;">Booking Found!</h3>
            
            <div style="line-height: 1.8; font-size: 16px;">
                <p><strong style="color: #D9BFA3;">Ref:</strong> <?= htmlspecialchars($booking['reference_no']) ?></p>
                <p><strong style="color: #D9BFA3;">Name:</strong> <?= htmlspecialchars($booking['guest_name']) ?></p>
                <p><strong style="color: #D9BFA3;">Date & Time:</strong> <?= date('M d, Y', strtotime($booking['booking_date'])) ?> at <?= date('g:i A', strtotime($booking['start_time'])) ?></p>
                <p><strong style="color: #D9BFA3;">Service:</strong> <?= htmlspecialchars($booking['service_name']) ?> (<?= htmlspecialchars($booking['massage_details'] ?? 'None') ?>)</p>
            </div>
            
            <div style="font-size: 22px; margin-top: 20px; border-top: 1px solid #6F4E37; padding-top: 20px; font-family: 'Cormorant Garamond', serif;">
                <strong>Total:</strong> ₱<?= number_format($booking['total_price'], 2) ?>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <script>
        function closeModal() {
            document.getElementById('bookingModal').style.display = 'none';
        }

        // Optional: Close modal if user clicks outside the content box
        window.onclick = function(event) {
            let modal = document.getElementById('bookingModal');
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>
</body>
</html>