<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

require 'db.php';

$error_message = "";
$success_message = "";

// 1. Set the Filter Date (Default to Today)
$filter_date = isset($_GET['filter_date']) ? $_GET['filter_date'] : date('Y-m-d');

// 2. FETCH BOOKINGS FOR THE SELECTED DATE ONLY
$stmt = $pdo->prepare("SELECT b.*, s.name as service_name FROM bookings b JOIN services s ON b.service_id = s.id WHERE b.booking_date = ? ORDER BY b.start_time ASC");
$stmt->execute([$filter_date]);
$bookings = $stmt->fetchAll();

// 3. Handle Therapist Assignment (Keep your existing logic here)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_therapist'])) {
    // ... (KEEP YOUR EXISTING THERAPIST LOGIC EXACTLY AS IS) ...
    
    // After updating, refresh the page to see changes and keep the filter date
    header("Location: admin.php?filter_date=" . urlencode($filter_date));
    exit;
}

// 4. Group bookings by Room Type for the Calendar
$calendar_data = [
    'SR-1' => [],
    'CS-1' => [],
    'FL-1' => []
];

foreach ($bookings as $b) {
    $service_name = strtolower($b['service_name']);
    if (strpos($service_name, 'single') !== false) {
        $calendar_data['SR-1'][] = $b;
    } elseif (strpos($service_name, 'couple') !== false) {
        $calendar_data['CS-1'][] = $b;
    } elseif (strpos($service_name, 'barkada') !== false || strpos($service_name, 'family') !== false) {
        $calendar_data['FL-1'][] = $b;
    }
}

// 5. Function to calculate position (Keep as is)
function getTimePosition($start_time, $end_time) {
    // ... (KEEP YOUR EXISTING getTimePosition FUNCTION EXACTLY AS IS) ...
}
?>