<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Bella Vista Oasis Spa</title> 
    
    <link rel="icon" type="image/png" href="logo.png">
    
    <link rel="stylesheet" href="style.css">
    <!-- Add this line for the 360 Tour -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pannellum@2.5.6/build/pannellum.css"/>
</head>
<body>
           
        <nav>
        <div class="logo">
            <a href="index.php" style="text-decoration:none; color: #FBF7F0; display:flex; align-items:center; font-family: 'Cormorant Garamond', serif; font-size: 26px; font-weight: 700;">
                <img src="logo.png" alt="Logo" style="width: 40px; height: 40px; object-fit: contain; margin-right: 10px;"> 
                Bella Vista Oasis Spa
            </a>
        </div>
                        <div class="nav-links">
            <?php session_start(); if(isset($_SESSION['customer_id'])): ?>
                <a href="my_account.php" style="color: #A9744F; font-weight: bold;">My Account</a>
            <?php else: ?>
                <!-- UPDATED LOG IN LINK -->
                <a href="customer_auth.php" class="nav-text-btn">Log in</a>
                
                <!-- UPDATED REGISTER LINK -->
                <a href="customer_auth.php?register=1" class="nav-text-btn">Register</a>
            <?php endif; ?>
            <!-- Change all Book Now links to this: -->
<a href="javascript:void(0);" onclick="openBookingModal()" class="btn">Book Now</a>
        </div>
    </nav>

    <!-- Replace your old <header> with this -->
    <header class="hero">
        <!-- The Slideshow Images -->
        <div class="hero-slider">
            <div class="slide active" style="background-image: url('hero1.png');"></div>
            <div class="slide" style="background-image: url('hero2.png');"></div>
            <div class="slide" style="background-image: url('hero3.png');"></div>
        </div>

        <!-- The Dark Overlay (so text is readable) -->
        <div class="hero-overlay"></div>

        <!-- The Text Content -->
        <div class="hero-content">
            <h1>A quiet sanctuary to<br>restore body and mind</h1>
            <p>Premium massage therapies and private lounge experiences, open daily from 10:00 AM to 11:00 PM.</p>
            <a href="javascript:void(0);" onclick="openBookingModal()" class="btn">Book Your Session</a>
            <a href="#services" class="btn btn-outline">View Services</a>
        </div>
    </header>

    <!-- START BACKGROUND WRAPPER (Wraps from About Us to Services) -->
    <div style="
    background-image: 
        linear-gradient(to bottom, #3B2A20 0%, transparent 15%, transparent 100%),
        url('long_bg.png'); 
    background-size: cover; 
    background-position: center top; 
    background-repeat: no-repeat;
">
        
        
        <!-- ABOUT US & HISTORY SECTION -->
        <section id="about" class="section" style="padding: 250px 50px 20px 50px; position: relative;">
            <div style="max-width: 1200px; margin: 0 auto; display: grid; grid-template-columns: 1fr 1fr; gap: 60px; align-items: start;">
                
                <!-- TOP LEFT: About Us Text -->
                <div>
                    <img src="outside_spa.png" alt="Bella Vista Spa Exterior" style="width: 100%; border-radius: 15px; box-shadow: 0 10px 20px rgba(59, 42, 32, 0.15); height: 100%; object-fit: cover;">
                </div>

                <!-- TOP RIGHT: Photo of Outside -->
                <div>
                    <h4 style="color: #45270E ; letter-spacing: 2px; margin-bottom: 10px; font-weight: 1000; font-size: xxx-large;">ABOUT US</h4>
                    <p style="font-size: 18px; line-height: 1.8; color: #3B2A20; font-weight: 500">
                        Bella Vista Oasis Spa is a peaceful sanctuary dedicated to holistic wellness, physical rejuvenation, and deep relaxation, offering premium massage therapies, therapeutic treatments, and private lounge experiences.
                    </p>
                </div>

                <!-- BOTTOM LEFT: Contact Info Card -->
                <div style="margin-top: 20px; ">
                    <h4 style="color: #45270E; letter-spacing: 2px; margin-bottom: 10px; font-weight: 1000; font-size: xxx-large;">OUR HISTORY</h4>
                    <p style="font-size: 18px; line-height: 1.8; color: #3B2A20; font-weight: 500;">
                        Established in 2021 as an extension of the Bella Vista estate, the spa grew into a premier standalone wellness center trusted by both local residents and tourists seeking professional relaxation therapies.
                    </p>
                </div>

                <!-- BOTTOM RIGHT: Our History Text -->
                <div style="margin-top: 20px;">
                    <div style="background: radial-gradient(circle, #fef6e7 0%, #f9e0bf 100%);; padding: 30px; border-radius: 15px; box-shadow: 0 15px 30px rgba(59, 42, 32, 0.15); text-align: center; border: 1px solid #D9BFA3; max-width: 400px; margin: 0 auto;">
                        <h3 style="font-size: xx-large; margin-bottom: 20px; color: #45270E; font-family: 'Cormorant Garamond', serif;">Contact Information</h3>
                        
                        <img src="logo3.png" alt="Bella Vista Logo" style="width: 80px; margin-bottom: 20px; opacity: 0.8;">
                        
                        <div style="text-align: left; font-size: 15px; color: #45270E; line-height: 2; margin-bottom: 25px;">
                            <div style="display: flex; justify-content: space-between; border-bottom: 1px solid #45270E ; padding-bottom: 10px; margin-bottom: 10px;">
                                <strong>Phone</strong> <span>09062858255</span>
                            </div>
                            <div style="display: flex; justify-content: space-between; border-bottom: 1px solid #45270E ; padding-bottom: 10px; margin-bottom: 10px;">
                                <strong>Hours</strong> <span>10 AM to 11 PM, Daily</span>
                            </div>
                            <div style="display: flex; justify-content: space-between;">
                                <strong>Email</strong> <span>bellavistaos@gmail.com</span>
                            </div>
                        </div>
                        
                        <a href="javascript:void(0);" onclick="openBookingModal()" class="btn">Book Now</a>
                    </div>
                </div>
            </div>
        </section>

        <!-- NEW: Explore Experiences Section -->
        <section class="section" style="padding: 20px 50px 80px 50px;">
            <div style="max-width: 1100px; margin: 0 auto;">
                <h2 style="font-size: 36px; margin-bottom: 40px; color: #45270E;">Explore Unparalleled Experiences</h2>

                <div class="experience-grid">
                    <!-- Card 1 -->
                    <div class="experience-card">
                        <img src="card1.png" alt="Relaxation Massages" class="exp-img">
                        <div class="exp-content">
                            <h3>Relaxation Massages</h3>
                            <p>Swedish, Aromatherapy, Foot Reflexology. Melt away stress and restore your peace of mind.</p>
                        </div>
                    </div>

                    <!-- Card 2 -->
                    <div class="experience-card">
                        <img src="card2.png" alt="Therapeutic Massages" class="exp-img">
                        <div class="exp-content">
                            <h3>Therapeutic Massages</h3>
                            <p>Deep Tissue, Shiatsu, Hilot. Targeted pressure to release deep-seated tension and pain.</p>
                        </div>
                    </div>

                    <!-- Card 3 -->
                    <div class="experience-card">
                        <img src="card3.png" alt="Warm Therapies" class="exp-img">
                        <div class="exp-content">
                            <h3>Warm Therapies</h3>
                            <p>Hot Stone, plus complimentary herbal tea in the Couples Suite. Deep warmth for ultimate relaxation.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

                <!-- SERVICES ACCORDION SECTION -->
        <section id="services" class="section" style="padding: 80px 50px;">
            
            <!-- The Translucent Card -->
            <div style="
                max-width: 1000px; 
                margin: 0 auto; 
                background: radial-gradient(circle, #fef6e7 0%, #f9e0bf 100%);
                backdrop-filter: blur(8px); /* Frosted glass effect */
                -webkit-backdrop-filter: blur(8px); /* For Safari */
                padding: 50px; 
                border-radius: 20px; 
                box-shadow: 0 10px 30px rgba(59, 42, 32, 0.1); /* Soft shadow */
                border: 1px solid rgba(255, 255, 255, 0.3);
            ">
                <h4 style="color: #45270E; letter-spacing: 1px; font-weight: 700;">SERVICES AND RATES</h4>
                <h2 style="font-size: 36px; margin-bottom: 40px; color: #3B2A20;">Choose your massage</h2>

                <div class="accordion-container">
                    <!-- ... YOUR EXISTING ACCORDION ITEMS (Swedish, etc.) ... -->
                
                    <!-- 1. Swedish -->
                    <div class="accordion-item">
                        <button class="accordion-header">
                            <span>Swedish</span>
                            <span class="accordion-icon">&#9660;</span>
                        </button>
                        <div class="accordion-content">
                            <p>Long, flowing strokes and gentle kneading across the full body to ease tension and improve circulation.</p>
                            <div class="price-pills">
                                <span class="price-pill">1 hour · ₱800</span>
                                <span class="price-pill">2 hours · ₱1,500</span>
                            </div>
                        </div>
                    </div>

                    <!-- 2. Foot Reflexology -->
                    <div class="accordion-item">
                        <button class="accordion-header">
                            <span>Foot Reflexology</span>
                            <span class="accordion-icon">&#9660;</span>
                        </button>
                        <div class="accordion-content">
                            <p>Focused pressure on points of the feet and lower legs to relieve tired legs and help you unwind.</p>
                            <div class="price-pills">
                                <span class="price-pill">1 hour · ₱800</span>
                                <span class="price-pill">2 hours · ₱1,500</span>
                            </div>
                        </div>
                    </div>

                    <!-- 3. Shiatsu -->
                    <div class="accordion-item">
                        <button class="accordion-header">
                            <span>Shiatsu</span>
                            <span class="accordion-icon">&#9660;</span>
                        </button>
                        <div class="accordion-content">
                            <p>A Japanese-style technique using rhythmic finger and palm pressure to release tightness and restore balance.</p>
                            <div class="price-pills">
                                <span class="price-pill">1 hour · ₱900</span>
                                <span class="price-pill">2 hours · ₱1,700</span>
                            </div>
                        </div>
                    </div>

                    <!-- 4. Hilot -->
                    <div class="accordion-item">
                        <button class="accordion-header">
                            <span>Hilot (Filipino)</span>
                            <span class="accordion-icon">&#9660;</span>
                        </button>
                        <div class="accordion-content">
                            <p>A traditional Filipino healing massage using warm oil and herbal heat to soothe aching muscles and joints.</p>
                            <div class="price-pills">
                                <span class="price-pill">1 hour · ₱1,000</span>
                                <span class="price-pill">2 hours · ₱1,900</span>
                            </div>
                        </div>
                    </div>

                    <!-- 5. Aromatherapy -->
                    <div class="accordion-item">
                        <button class="accordion-header">
                            <span>Aromatherapy</span>
                            <span class="accordion-icon">&#9660;</span>
                        </button>
                        <div class="accordion-content">
                            <p>Light to medium strokes with essential oils chosen for calm, helping quiet the mind and ease stress.</p>
                            <div class="price-pills">
                                <span class="price-pill">1 hour · ₱1,000</span>
                                <span class="price-pill">2 hours · ₱1,900</span>
                            </div>
                        </div>
                    </div>

                    <!-- 6. Deep Tissue -->
                    <div class="accordion-item">
                        <button class="accordion-header">
                            <span>Deep Tissue</span>
                            <span class="accordion-icon">&#9660;</span>
                        </button>
                        <div class="accordion-content">
                            <p>Slow, firm pressure on the deeper muscle layers to work out knots and long-held tightness.</p>
                            <div class="price-pills">
                                <span class="price-pill">1 hour · ₱1,100</span>
                                <span class="price-pill">2 hours · ₱2,100</span>
                            </div>
                        </div>
                    </div>

                    <!-- 7. Hot Stone -->
                    <div class="accordion-item">
                        <button class="accordion-header">
                            <span>Hot Stone</span>
                            <span class="accordion-icon">&#9660;</span>
                        </button>
                        <div class="accordion-content">
                            <p>Smooth heated stones placed on and glided over the body to melt tension and deepen relaxation.</p>
                            <div class="price-pills">
                                <span class="price-pill">1 hour · ₱1,300</span>
                                <span class="price-pill">2 hours · ₱2,500</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </div> 
    <!-- END OF BACKGROUND WRAPPER (long_bg stops here) -->


    <!-- 360 VIRTUAL TOUR SECTION (Outside the wrapper, back to normal background) -->
    <section id="tour" class="section" style="background: radial-gradient(circle, #F9E8C9 0%, #D8A45F 100%); padding: 80px 50px;">
        <div style="max-width: 1100px; margin: 0 auto;">
            <div style="text-align: center; margin-bottom: 30px;">
                <h4 style="color: #45270E; letter-spacing: 1px; font-weight: 700;">VIRTUAL TOUR</h4>
                <h2 style="font-size: 36px; margin-bottom: 15px; color: #45270E;">Step inside Bella Vista</h2>
                <p style="color: #45270E; font-size: 18px;">Click and drag to look around. Use the buttons below to explore different rooms.</p>
            </div>

            <!-- Tour Buttons -->
            <div style="display: flex; justify-content: center; gap: 15px; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="btn tour-btn active-tour" onclick="switchTour('reception', this)" style="background: #6F4E37 ; color: #fff !important;">Reception Area</button>
                <button class="btn tour-btn" onclick="switchTour('single', this)" style="background: transparent; border: 1px solid #6F4E37; color: #6F4E37 !important;">Single Room</button>
                <button class="btn tour-btn" onclick="switchTour('couple', this)" style="background: transparent; border: 1px solid #6F4E37; color: #6F4E37 !important;">Couples Suite</button>
                <button class="btn tour-btn" onclick="switchTour('family', this)" style="background: transparent; border: 1px solid #6F4E37; color: #6F4E37 !important;">Family Lounge</button>
            </div>
            
            <!-- The 360 Viewer Container -->
            <div id="panorama" style="width: 100%; height: 500px; border-radius: 15px; overflow: hidden; box-shadow: 0 10px 30px rgba(59, 42, 32, 0.15);"></div>
        </div>
    </section>

    <!-- FOOTER -->
    <footer style="background-image: url('footer_bg.png'); background-size: cover; background-position: center top; background-repeat: no-repeat; padding: 50px 20px 30px 20px; text-align: center; font-family: 'Jost', sans-serif; border-top: 1px solid rgb(238, 216, 189);">
        
        <div style="display: flex; justify-content: center; align-items: center; gap: 40px; margin-bottom: 20px; flex-wrap: wrap;">
            <img src="logo3.png" alt="Bella Vista" style="height: 80px; opacity: 100%;">
            <div style="width: 1px; height: 40px; background: #6F4E37 ;"></div>
            <img src="logo4.png" alt="Bella Vista" style="height: 80px; opacity: 100%;">
        </div>

        <!--tagline-->
        <div>
            <p style="font-family: 'Montserrat', serif; font-size: large; color: #45270E; font-weight:bolder; margin-top: 15px; margin-bottom: 15px;">Where Beauty Meets Serenity</p>
        </div>

                <!-- Links -->
        <div style="margin-bottom: 15px; font-size: 14px; color: #6F4E37;">
            <a href="privacy_policy.php" style="color: #45270E; text-decoration: none; font-weight: 500; font-size: 15px;">Privacy Policy</a>
            <span style="margin: 0 10px; color: #6F4E37 ;">|</span>
            <a href="terms_conditions.php" style="color: #45270E; text-decoration: none; font-weight: 500; font-size: 15px;">Terms & Conditions</a>
            <span style="margin: 0 10px; color: #6F4E37 ;">|</span>
            <a href="safety_security.php" style="color: #45270E; text-decoration: none; font-weight: 500; font-size: 15px;">Safety & Security</a>
        </div>

        <!-- Copyright -->
        <p style="font-size: 20px; color: #45270E; margin: 0;">
            &copy; <?= date('Y') ?> Bella Vista Oasis Spa. All Rights Reserved.
        </p>
    </footer>

    <!-- Add this script at the bottom of index.php -->
    <script>
        let currentSlide = 0;
        const slides = document.querySelectorAll('.slide');
        const totalSlides = slides.length;

        function showSlide(index) {
            slides.forEach(slide => {
                slide.classList.remove('active');
            });
            slides[index].classList.add('active');
        }

        function changeSlide(direction) {
            currentSlide += direction;
            if (currentSlide >= totalSlides) {
                currentSlide = 0;
            } else if (currentSlide < 0) {
                currentSlide = totalSlides - 1;
            }
            showSlide(currentSlide);
        }

        setInterval(() => {
            changeSlide(1);
        }, 5000);
    </script>

    <script>
        const accordions = document.querySelectorAll('.accordion-header');

        accordions.forEach(acc => {
            acc.addEventListener('click', function() {
                this.parentElement.classList.toggle('active');
                const panel = this.nextElementSibling;

                if (panel.style.maxHeight) {
                    panel.style.maxHeight = null; 
                } else {
                    panel.style.maxHeight = panel.scrollHeight + "px"; 
                }
            });
        });
    </script>
            
    <!-- Load Pannellum JS -->
    <script src="https://cdn.jsdelivr.net/npm/pannellum@2.5.6/build/pannellum.js"></script>
    
    <script>
        const viewer = pannellum.viewer('panorama', {
            "default": {
                "firstScene": "reception",
                "autoLoad": true,
                "autoRotate": -1.5,
                "showControls": true,
                "compass": false
            },
            "scenes": {
                "reception": {
                    "panorama": "reception_360.png", 
                    "type": "equirectangular"
                },
                "single": {
                    "panorama": "single_360.png", 
                    "type": "equirectangular"
                },
                "couple": {
                    "panorama": "couple_360.png", 
                    "type": "equirectangular"
                },
                "family": {
                    "panorama": "family_360.png", 
                    "type": "equirectangular"
                }
            }
        });

        function switchTour(sceneId, btnElement) {
            viewer.loadScene(sceneId);
            
            let buttons = document.querySelectorAll('.tour-btn');
            buttons.forEach(btn => {
                btn.style.setProperty('background', 'transparent', 'important');
                btn.style.setProperty('color', '#6F4E37', 'important');
                btn.style.setProperty('border', '1px solid #6F4E37', 'important');
            });
            
            btnElement.style.setProperty('background', '#6F4E37', 'important');
            btnElement.style.setProperty('color', '#fff', 'important');
        }
    </script>
        <!-- BOOKING OPTIONS MODAL -->
    <div id="bookingModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.6); backdrop-filter: blur(5px); z-index: 3000; justify-content: center; align-items: center;">
        <div style="background: #FBF7F0; padding: 40px; border-radius: 20px; width: 90%; max-width: 450px; box-shadow: 0 15px 40px rgba(0,0,0,0.3); text-align: center; border: 1px solid #D9BFA3; animation: popIn 0.3s ease-out;">
            
            <h2 style="font-family: 'Cormorant Garamond', serif; font-size: 32px; color: #3B2A20; margin-bottom: 10px;">How would you like to book?</h2>
            <p style="color: #6F4E37; margin-bottom: 30px; font-size: 15px;">Create an account to save your details, or continue as a guest.</p>
            
            <div style="display: flex; flex-direction: column; gap: 15px;">
                <!-- Register Option -->
                <a href="customer_auth.php?register=1" class="btn" style="background: #6F4E37; color: #fff !important; padding: 15px; font-size: 16px;">Register Now</a>
                
                <div style="display: flex; gap: 15px; margin-top: 10px;">
                    <!-- Login Option -->
                    <a href="customer_auth.php" class="btn" style="flex: 1; background: transparent; border: 1px solid #6F4E37; color: #6F4E37 !important; padding: 12px;">Have an account? Log In</a>
                    
                    <!-- Guest Option -->
                    <a href="booking.php" class="btn" style="flex: 1; background: transparent; border: 1px solid #6F4E37; color: #6F4E37 !important; padding: 20px;">Continue as Guest</a>
                </div>
            </div>

            <span onclick="closeBookingModal()" style="display: block; margin-top: 20px; font-size: 13px; color: #A9744F; cursor: pointer; text-decoration: underline;">Cancel</span>
        </div>
    </div>

    <script>
        function openBookingModal() {
            document.getElementById('bookingModal').style.display = 'flex';
        }
        function closeBookingModal() {
            document.getElementById('bookingModal').style.display = 'none';
        }
        window.onclick = function(event) {
            let modal = document.getElementById('bookingModal');
            if (event.target == modal) { modal.style.display = "none"; }
        }
    </script>
</body>
</html>