<?php
date_default_timezone_set('Asia/Manila'); 
session_start();

// Check if user is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

require 'db.php';

// Fetch ALL bookings from the database
$stmt = $pdo->prepare("SELECT b.*, s.name as service_name FROM bookings b JOIN services s ON b.service_id = s.id ORDER BY b.booking_date DESC, b.start_time DESC");
$stmt->execute();
$bookings = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>All Bookings | Admin</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/png" href="logo.png">
    <style>
        #searchInput {
            padding: 10px 15px;
            border: 1px solid #D9BFA3;
            border-radius: 8px;
            font-family: 'Jost', sans-serif;
            width: 300px;
            background: #FBF7F0;
        }
        .status-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
            display: inline-block;
            text-align: center;
            min-width: 80px;
        }
    </style>
</head>
<body>
    <div class="admin-layout">
        <!-- SIDEBAR -->
        <div class="sidebar">
            <div style="display:flex; align-items:center; color:#FBF7F0; margin-bottom:30px;">
                <img src="logo.png" alt="Logo" style="width: 35px; height: 35px; object-fit: contain; margin-right: 10px;">
                <h2 style="margin: 0;">Admin</h2>
            </div>
            <a href="admin.php" class="<?= basename($_SERVER['PHP_SELF']) == 'admin.php' ? 'active' : '' ?>">Dashboard</a>
            <a href="admin_all_bookings.php" class="<?= basename($_SERVER['PHP_SELF']) == 'admin_all_bookings.php' ? 'active' : '' ?>">All Bookings</a>
            <a href="admin_new.php" class="<?= basename($_SERVER['PHP_SELF']) == 'admin_new.php' ? 'active' : '' ?>">New Reservation</a>
            <a href="admin_therapists.php" class="<?= basename($_SERVER['PHP_SELF']) == 'admin_therapists.php' ? 'active' : '' ?>">Therapists</a>
            <a href="logout.php" onclick="return confirm('Are you sure you want to log out of the Admin Portal?');">Sign out</a>
        </div>

        <div class="main-content admin-main-bg">
            <!-- TOP BANNER -->
            <div style="background-color: #3B2A20; border-radius: 10px; padding: 20px 30px; display: flex; align-items: center; margin-bottom: 40px; box-shadow: 0 4px 10px rgba(0,0,0,0.1);">
                <img src="logo.png" alt="Logo" style="width: 45px; height: 45px; object-fit: contain; margin-right: 15px;">
                <div>
                    <h2 style="color: #FBF7F0; font-size: 24px; margin: 0; font-family: 'Cormorant Garamond', serif;">Bella Vista Oasis Spa</h2>
                    <p style="color: #D9BFA3; font-size: 13px; margin: 5px 0 0 0;">Complete booking history</p>
                </div>
            </div>

            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h1 style="font-size: 32px; color: #3B2A20; margin: 0; font-family: 'Cormorant Garamond', serif;">All Bookings</h1>
                <input type="text" id="searchInput" onkeyup="searchTable()" placeholder="Search by guest name or ref...">
            </div>

            <!-- ALL BOOKINGS TABLE -->
            <div style="background: #F3E9DA; padding: 20px; border-radius: 15px; overflow-x:auto; box-shadow: 0 5px 15px rgba(0,0,0,0.05);">
                <table id="bookingsTable" style="width: 100%; border-collapse: collapse; text-align: left;">
                    <thead>
                        <tr style="border-bottom: 1px solid #D9BFA3;">
                            <th style="padding: 15px 10px;">Ref</th>
                            <th style="padding: 15px 10px;">Date</th>
                            <th style="padding: 15px 10px;">Guest</th>
                            <th style="padding: 15px 10px;">Service</th>
                            <th style="padding: 15px 10px;">Time</th>
                            <th style="padding: 15px 10px;">Total</th>
                            <th style="padding: 15px 10px;">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        // Get current date and time for comparison
                        $current_datetime = date('Y-m-d H:i:s');
                        
                        foreach($bookings as $b): 
                            // Combine booking date and time for accurate comparison
                            $booking_start = date('Y-m-d H:i:s', strtotime($b['booking_date'] . ' ' . $b['start_time']));
                            $booking_end = date('Y-m-d H:i:s', strtotime($b['booking_date'] . ' ' . $b['end_time']));
                            
                            // Determine Status
                            if ($current_datetime > $booking_end) {
                                $status_text = "Completed";
                                $status_bg = "#6F4E37"; // Dark Brown
                                $status_color = "#D9BFA3";
                            } elseif ($current_datetime >= $booking_start && $current_datetime <= $booking_end) {
                                $status_text = "Active";
                                $status_bg = "#A9744F"; // Caramel
                            } else {
                                $status_text = "Upcoming";
                                $status_bg = "#D9BFA3"; // Beige
                                $status_color = "#3B2A20"; // Dark text for light bg
                            }
                        ?>
                        <tr style="border-bottom: 1px solid #D9BFA3;">
                            <td style="padding: 15px 10px; white-space: nowrap; font-weight: bold;">
                                <?= $b['reference_no'] ?>
                            </td>
                            <td style="padding: 15px 10px; white-space: nowrap;">
                                <?= date('M d, Y', strtotime($b['booking_date'])) ?>
                            </td>
                            <td style="padding: 15px 10px;">
                                <strong><?= htmlspecialchars($b['guest_name'] ?? 'N/A') ?></strong><br>
                                <span style="font-size: 12px; color: #6F4E37;"><?= htmlspecialchars($b['mobile'] ?? '') ?></span>
                            </td>
                            <td style="padding: 15px 10px; width: 20%;">
                                <?= $b['service_name'] ?>
                                <?php if(!empty($b['massage_details'])): ?>
                                    <br><span style="font-size: 12px; color: #A9744F;"><i><?= htmlspecialchars($b['massage_details']) ?></i></span>
                                <?php endif; ?>
                            </td>
                            <td style="padding: 15px 10px; white-space: nowrap;">
                                <?= date('g:i A', strtotime($b['start_time'])) ?> - <?= date('g:i A', strtotime($b['end_time'])) ?>
                            </td>
                            <td style="padding: 15px 10px; white-space: nowrap;">
                                ₱<?= number_format($b['total_price'],2) ?>
                            </td>
                                                        <td style="padding: 15px 10px;">
                                <span class="status-badge" style="background: <?= $status_bg ?>; color: <?= $status_color ?>;">
                                    <?= $status_text ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- SIMPLE SEARCH SCRIPT -->
    <script>
        function searchTable() {
            let input = document.getElementById("searchInput").value.toLowerCase();
            let table = document.getElementById("bookingsTable");
            let tr = table.getElementsByTagName("tr");

            for (let i = 1; i < tr.length; i++) {
                let rowText = tr[i].textContent || tr[i].innerText;
                if (rowText.toLowerCase().indexOf(input) > -1) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }
        }
    </script>
</body>
</html>