<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Terms & Conditions | Bella Vista Oasis Spa</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/png" href="logo.png">
    <style>
        .policy-container { max-width: 800px; margin: 100px auto; background: radial-gradient(circle, #F9E8C9 0%, #D8A45F 100%); padding: 50px; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); border: 1px solid #6F4E37 ; }
        .policy-container h1 { color: #3B2A20; margin-bottom: 20px; font-size: 36px; }
        .policy-container h2 { color: #45270E; margin-top: 30px; margin-bottom: 10px; font-size: 22px; }
        .policy-container p, .policy-container ul { color: #5C3E19; line-height: 1.8; margin-bottom: 15px; font-size: 16px; }
        .policy-container ul { padding-left: 20px; }
          /* ADD THIS BODY RULE TO CHANGE THE PAGE BACKGROUND */
        body::before {
            content: "";
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            
            /* REPLACE THIS URL WITH YOUR OWN IMAGE IF YOU WANT */
            background-image: url('policies_bg.png');  
            background-size: cover;
            background-position: center;
            
            /* LOW TRANSPARENCY (0.15 means 15% visible) */
            opacity: 100%; 
        }
    </style>
</head>
<body>
    <nav>
        <div class="logo">
            <a href="index.php" style="text-decoration:none; color: #FBF7F0; display:flex; align-items:center; font-family: 'Cormorant Garamond', serif; font-size: 26px; font-weight: 700;">
                <img src="logo.png" alt="Logo" style="width: 40px; height: 40px; object-fit: contain; margin-right: 10px;"> 
                Bella Vista Oasis Spa
            </a>
        </div>
        <div class="nav-links">
            <a href="index.php" class="btn" style="background: #6F4E37 ; color: #FBF7F0 !important;">Back to Home</a>
        </div>
    </nav>

    <div class="policy-container">
        <h1>Terms & Conditions</h1>
        <p>Last updated: <?= date('F d, Y') ?></p>
        
        <p>Welcome to Bella Vista Oasis Spa. By booking an appointment or using our services, you agree to the following terms and conditions. Please read them carefully.</p>

        <h2>1. Arrival & Grace Period</h2>
        <p>Clients must arrive at least <strong>15 minutes</strong> before their scheduled time. Late arrivals will result in a shortened session time to ensure subsequent bookings remain on schedule.</p>

        <h2>2. Cancellation Policy</h2>
        <p>Cancellations or rescheduling must be done at least <strong>6 hours</strong> prior to the appointment. Late cancellations will forfeit any downpayment made.</p>

        <h2>3. Health Declaration</h2>
        <p>Clients are required to disclose any medical conditions, injuries, or pregnancy prior to selecting their service during the booking process. Bella Vista Oasis Spa reserves the right to refuse service if a health condition poses a risk.</p>

        <h2>4. Quiet Environment</h2>
        <p>To preserve the peaceful ambiance of the spa, absolute silence and low volume must be maintained within the premises. Please silence mobile devices.</p>

        <h2>5. Cleaning Gap Rule</h2>
        <p>A strict 30-minute cleaning and sanitization gap is automatically blocked after every session to maintain the highest hygiene standards.</p>
    </div>
</body>
</html>