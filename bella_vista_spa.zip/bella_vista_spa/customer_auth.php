<?php
session_start();
require 'db.php';

$error = "";

// If already logged in, go to account
if (isset($_SESSION['customer_id'])) {
    header("Location: my_account.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['register'])) {
        $name = trim($_POST['name']);
        $email = trim($_POST['email']);
        $mobile = trim($_POST['mobile']);
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];
        
        // Server-side validation
        if ($password !== $confirm_password) {
            $error = "Passwords do not match.";
        } elseif (strlen($password) < 8) {
            $error = "Password must be at least 8 characters long.";
        } else {
            // Check if email exists
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $error = "Email already registered. Please log in.";
            } else {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("INSERT INTO users (name, email, mobile, password, role) VALUES (?, ?, ?, ?, 'customer')");
                if ($stmt->execute([$name, $email, $mobile, $hashed_password])) {
                    $_SESSION['customer_id'] = $pdo->lastInsertId();
                    $_SESSION['customer_name'] = $name;
                    header("Location: my_account.php");
                    exit;
                } else {
                    $error = "Something went wrong. Please try again.";
                }
            }
        }
    } elseif (isset($_POST['login'])) {
        $email = trim($_POST['email']);
        $password = $_POST['password'];
        
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND role = 'customer'");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['customer_id'] = $user['id'];
            $_SESSION['customer_name'] = $user['name'];
            header("Location: my_account.php");
            exit;
        } else {
            $error = "Invalid email or password.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Customer Portal | Bella Vista</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/png" href="logo.png">
    <style>
        /* --- PAGE BACKGROUND & HEADER FIX --- */
        body {
            position: relative;
            background-color: #FBF7F0;
            z-index: 0;
            margin: 0;
            padding: 0;
            padding-top: 90px; /* Pushes content below the fixed header */
        }

        /* Adds the background image with low transparency */
        body::before {
            content: "";
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            background-image: url('booking_bg.png'); 
            background-size: cover;
            background-position: center;
            opacity: 100%; 
        }

        /* Header Style (Matches Booking Page) */
        nav {
            background-color: #3B2A20 !important;
            position: fixed !important;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000 !important;
            padding: 20px 50px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid #D9BFA3;
            box-sizing: border-box;
        }

        /* --- AUTH CARD STYLES --- */
        .auth-container { 
            max-width: 500px; 
            margin: 50px auto 80px auto; 
            background: radial-gradient(circle, #F9E8C9 0%, #D8A45F 100%); 
            padding: 40px; 
            border-radius: 20px; 
            box-shadow: 0 15px 35px rgba(59, 42, 32, 0.15); 
            position: relative;
            z-index: 1;
        }
        
        .auth-form { 
            background: #FBF7F0; 
            padding: 30px; 
            border-radius: 10px; 
            border: 1px solid #D9BFA3; 
        }
        
        .toggle-btn { 
            background: transparent; 
            border: none; 
            color: #A9744F; 
            text-decoration: underline; 
            cursor: pointer; 
            font-family: 'Jost', sans-serif; 
            font-size: 14px; 
            margin-top: 15px; 
            display: block; 
            text-align: center; 
            width: 100%;
        }
        
        .error-msg { 
            background: #f8d7da; 
            color: #721c24; 
            padding: 10px; 
            border-radius: 5px; 
            margin-bottom: 20px; 
            font-size: 14px; 
            text-align: center; 
            border: 1px solid #f5c6cb; 
        }
    </style>
</head>
<body>
    <!-- FIXED HEADER -->
    <nav>
        <div class="logo">
            <a href="index.php" style="text-decoration:none; color: #FBF7F0; display:flex; align-items:center; font-family: 'Cormorant Garamond', serif; font-size: 26px; font-weight: 700;">
                <img src="logo.png" alt="Logo" style="width: 40px; height: 40px; object-fit: contain; margin-right: 10px;"> 
                Bella Vista Oasis Spa
            </a>
        </div>
        <div>
            <a href="index.php" class="btn" style="background: #FBF7F0; color: #3B2A20 !important;">Back to Home</a>
        </div>
    </nav>

    <!-- MAIN CARD -->
    <div class="auth-container">
        <h2 style="text-align: center; margin-bottom: 25px; color: #3B2A20; font-family: 'Cormorant Garamond', serif; font-size: 32px;">Customer Portal</h2>
        
        <?php if($error): ?>
            <div class="error-msg"><?= $error ?></div>
        <?php endif; ?>

        <!-- LOGIN FORM -->
        <div id="login-form" class="auth-form" style="<?= (isset($_GET['register']) || isset($_POST['register'])) ? 'display: none;' : 'display: block;' ?>">
            <h3 style="margin-bottom: 20px; color: #45270E; font-size: 24px;">Log In</h3>
            <form method="POST">
                <div class="form-group">
                    <label style="color: #45270E; font-weight: 500;">Email</label>
                    <input type="email" name="email" required placeholder="e.g. abcd@example.com" style="background: #f5e5cf;">
                </div>
                <div class="form-group">
                    <label style="color: #45270E; font-weight: 500;">Password</label>
                    <input type="password" name="password" required style="background: #f5e5cf;">
                </div>
                
                <!-- FORGOT PASSWORD LINK -->
                <div style="text-align: right; margin-bottom: 15px;">
                    <a href="#" style="font-size: 13px; color: #A9744F; text-decoration: underline;">Forgot password?</a>
                </div>

                <button type="submit" name="login" class="btn" style="width: 100%; margin-top: 5px; padding: 12px;">Log In</button>
            </form>
            
            <button class="toggle-btn" onclick="toggleForms()">Don't have an account? Register here.</button>
            
            <!-- GUEST LOOKUP LINK -->
            <div style="text-align: center; margin-top: 20px; border-top: 1px solid #D9BFA3; padding-top: 20px;">
                <a href="guest_lookup.php" style="color: #6F4E37; font-size: 14px; font-weight: 500; text-decoration: underline;">Guest? Find your booking here.</a>
            </div>
        </div>

        <!-- REGISTER FORM -->
        <div id="register-form" class="auth-form" style="<?= (isset($_GET['register']) || isset($_POST['register'])) ? 'display: block;' : 'display: none;' ?>">
            <h3 style="margin-bottom: 20px; color: #45270E; font-size: 24px;">Create Account</h3>
            <form method="POST" onsubmit="return validateForm()">
                <div class="form-group">
                    <label style="color: #45270E; font-weight: 500;">Full Name</label>
                    <input type="text" name="name" id="reg_name" required placeholder="e.g. Jane Doe" minlength="3" pattern="[A-Za-z\s]+" title="Please enter letters and spaces only." style="background: #f5e5cf;">
                </div>
                <div class="form-group">
                    <label style="color: #45270E; font-weight: 500;">Email</label>
                    <input type="email" name="email" id="reg_email" required placeholder="jane@example.com" style="background: #f5e5cf;">
                </div>
                <div class="form-group">
                    <label style="color: #45270E; font-weight: 500;">Mobile Number</label>
                    <input type="text" name="mobile" required placeholder="09123456789" pattern="09[0-9]{9}" title="Mobile number must be 11 digits starting with 09." maxlength="11" style="background: #f5e5cf;">
                </div>
                <div class="form-group">
                    <label style="color: #45270E; font-weight: 500;">Password</label>
                    <input type="password" name="password" id="reg_password" required minlength="8" title="Password must be at least 8 characters." style="background: #f5e5cf;">
                </div>
                <div class="form-group">
                    <label style="color: #45270E; font-weight: 500;">Confirm Password</label>
                    <input type="password" name="confirm_password" id="reg_confirm" required minlength="8" style="background: #f5e5cf;">
                    <span id="password-error" style="color: #dc3545; font-size: 12px; display: none;">Passwords do not match.</span>
                </div>
                <button type="submit" name="register" class="btn" style="width: 100%; margin-top: 10px; padding: 12px;">Sign Up</button>
            </form>
            
            <button class="toggle-btn" onclick="toggleForms()">Already have an account? Log in here.</button>
            
            <!-- GUEST LOOKUP LINK -->
            <div style="text-align: center; margin-top: 20px; border-top: 1px solid #D9BFA3; padding-top: 20px;">
                <a href="guest_lookup.php" style="color: #6F4E37; font-size: 14px; font-weight: 500; text-decoration: underline;">Guest? Find your booking here.</a>
            </div>
        </div>
    </div>

    <script>
        function toggleForms() {
            let login = document.getElementById('login-form');
            let register = document.getElementById('register-form');
            if (login.style.display === 'none') {
                login.style.display = 'block';
                register.style.display = 'none';
            } else {
                login.style.display = 'none';
                register.style.display = 'block';
            }
        }

        // Real-time password matching validation
        document.getElementById('reg_confirm').addEventListener('input', function() {
            let pass = document.getElementById('reg_password').value;
            let confirm = this.value;
            let errorSpan = document.getElementById('password-error');

            if (pass !== confirm) {
                errorSpan.style.display = 'block';
                this.setCustomValidity("Passwords do not match.");
            } else {
                errorSpan.style.display = 'none';
                this.setCustomValidity("");
            }
        });

        // Form submission check
        function validateForm() {
            let pass = document.getElementById('reg_password').value;
            let confirm = document.getElementById('reg_confirm').value;
            if (pass !== confirm) {
                alert("Passwords do not match!");
                return false;
            }
            return true;
        }
    </script>
</body>
</html>