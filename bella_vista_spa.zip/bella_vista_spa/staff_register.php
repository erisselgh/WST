<?php
session_start();
require 'db.php';

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $role = $_POST['role']; 

    // Server-side validation
    if ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } elseif (strlen($password) < 8) {
        $error = "Password must be at least 8 characters long.";
    } else {
        // Check if email exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = "Email already registered. Please log in.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
            if ($stmt->execute([$name, $email, $hashed_password, $role])) {
                header("Location: login.php?registered=1");
                exit;
            } else {
                $error = "Something went wrong. Please try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Staff Registration | Bella Vista</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/png" href="logo.png">
    <style>
        body { background: #F3E9DA; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; font-family: 'Jost', sans-serif; padding: 20px; }
        .login-wrapper { display: flex; background: #FBF7F0; border-radius: 20px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1); width: 800px; max-width: 100%; min-height: 600px; }
        .login-left { background: #3B2A20; color: #FBF7F0; padding: 50px; width: 45%; display: flex; flex-direction: column; justify-content: center; }
        .login-left img { width: 80px; margin-bottom: 20px; object-fit: contain; }
        .login-left h2 { font-size: 32px; margin-bottom: 15px; font-family: 'Cormorant Garamond', serif; }
        .login-right { padding: 50px; width: 55%; display: flex; flex-direction: column; justify-content: center; }
        .login-right h2 { font-size: 28px; margin-bottom: 20px; color: #3B2A20; font-family: 'Cormorant Garamond', serif; }
        .error-msg { background: #f8d7da; border: 1px solid #f5c6cb; padding: 10px; border-radius: 5px; font-size: 13px; margin-bottom: 20px; color: #721c24; }
        .form-group { margin-bottom: 15px; }
        .form-group label { color: #45270E; font-weight: 500; display: block; margin-bottom: 5px; }
        .form-group input, .form-group select { background: #f5e5cf; width: 100%; padding: 12px; border: 1px solid #D9BFA3; border-radius: 8px; box-sizing: border-box; font-family: 'Jost', sans-serif;}
    </style>
</head>
<body>

    <div class="login-wrapper">
        <!-- LEFT SIDE -->
        <div class="login-left">
            <img src="logo3.png" alt="Logo">
            <h2>Join the Team</h2>
            <p style="font-size: 14px; line-height: 1.6; color: #D9BFA3;">
                Register as a receptionist or therapist to access the internal staff portal and manage appointments.
            </p>
        </div>

        <!-- RIGHT SIDE -->
        <div class="login-right">
            <h2>Staff Registration</h2>
            
            <?php if($error): ?>
                <div class="error-msg"><?= $error ?></div>
            <?php endif; ?>

            <form method="POST" onsubmit="return validateForm()">
                <div class="form-group">
                    <label>Full Name</label>
                    <!-- Restricts numbers and special characters -->
                    <input type="text" name="name" id="staff_name" required placeholder="e.g. Maria Santos" 
                           pattern="[A-Za-z\s\.\-]+" title="Please enter letters and spaces only.">
                </div>
                
                <div class="form-group">
                    <label>Staff Email</label>
                    <!-- Requires a valid email format -->
                    <input type="email" name="email" required placeholder="staff@bellavista.com">
                </div>

                <div class="form-group">
                    <label>Password</label>
                    <!-- Requires minimum 8 characters -->
                    <input type="password" name="password" id="staff_password" required minlength="8" 
                           title="Password must be at least 8 characters.">
                </div>

                <div class="form-group">
                    <label>Confirm Password</label>
                    <input type="password" name="confirm_password" id="staff_confirm" required minlength="8">
                    <span id="password-error" style="color: #dc3545; font-size: 12px; display: none;">Passwords do not match.</span>
                </div>

                <div class="form-group">
                    <label>Role</label>
                    <select name="role" required>
                        <option value="receptionist">Receptionist</option>
                        <option value="therapist">Therapist</option>
                    </select>
                </div>

                <button type="submit" class="btn" style="width: 100%; margin-top: 15px; background: #6F4E37; color: #FBF7F0; padding: 12px;">Register Account</button>
            </form>

            <p style="text-align: center; margin-top: 20px; font-size: 14px;">
                <a href="login.php" style="color: #A9744F; text-decoration: underline;">Already have an account? Sign in.</a>
            </p>
        </div>
    </div>

    <script>
        // Real-time password matching validation
        document.getElementById('staff_confirm').addEventListener('input', function() {
            let pass = document.getElementById('staff_password').value;
            let confirm = this.value;
            let errorSpan = document.getElementById('password-error');

            if (pass !== confirm) {
                errorSpan.style.display = 'block';
                this.setCustomValidity("Passwords do not match.");
            } else {
                errorSpan.style.display = 'none';
                this.setCustomValidity("");
            }
        });

        // Final check before submission
        function validateForm() {
            let pass = document.getElementById('staff_password').value;
            let confirm = document.getElementById('staff_confirm').value;
            if (pass !== confirm) {
                alert("Passwords do not match!");
                return false;
            }
            return true;
        }
    </script>
</body>
</html>