<?php
session_start();

// Check if user is logged in AND is either admin or receptionist
if (!isset($_SESSION['admin_logged_in']) || !in_array($_SESSION['staff_role'], ['admin', 'receptionist'])) {
    header("Location: login.php");
    exit;
}

require 'db.php';

$error_message = "";
$success_message = "";

// 1. Set the Filter Date (Default to Today)
$filter_date = isset($_GET['filter_date']) ? $_GET['filter_date'] : date('Y-m-d');

// 2. Handle Therapist Assignment BEFORE fetching data for the calendar
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_therapist'])) {
    $booking_id = $_POST['booking_id'];
    $therapist = $_POST['therapist'];
    $date = $_POST['booking_date'];
    $new_start = $_POST['start_time'];
    $new_end = $_POST['end_time'];
    
    // Check for conflicts
    $check_sql = "SELECT reference_no, start_time, end_time FROM bookings 
                  WHERE therapist = ? AND booking_date = ? AND id != ? 
                  AND (start_time < ? AND end_time > ?)";
    
    $check_stmt = $pdo->prepare($check_sql);
    $check_stmt->execute([$therapist, $date, $booking_id, $new_end, $new_start]);
    $conflict = $check_stmt->fetch();
    
    if ($conflict) {
        $error_message = "Conflict! $therapist is already assigned to Booking {$conflict['reference_no']} from " . 
                         date('g:i A', strtotime($conflict['start_time'])) . " to " . 
                         date('g:i A', strtotime($conflict['end_time'])) . " on this date.";
    } else {
        $update_stmt = $pdo->prepare("UPDATE bookings SET therapist = ? WHERE id = ?");
        $update_stmt->execute([$therapist, $booking_id]);
        $success_message = "Successfully assigned $therapist to the booking.";
        
        // Refresh the page keeping the current date filter
        header("Location: admin.php?filter_date=" . urlencode($filter_date) . "&success=1");
        exit;
    }
}

// 3. FETCH BOOKINGS FOR THE SELECTED DATE ONLY
$stmt = $pdo->prepare("SELECT b.*, s.name as service_name FROM bookings b JOIN services s ON b.service_id = s.id WHERE b.booking_date = ? ORDER BY b.start_time ASC");
$stmt->execute([$filter_date]);
$bookings = $stmt->fetchAll();

// 4. Group bookings by Room Type for the Calendar
$calendar_data = [
    'SR-1' => [],
    'CS-1' => [],
    'FL-1' => []
];

foreach ($bookings as $b) {
    $service_name = strtolower($b['service_name']);
    if (strpos($service_name, 'single') !== false) {
        $calendar_data['SR-1'][] = $b;
    } elseif (strpos($service_name, 'couple') !== false) {
        $calendar_data['CS-1'][] = $b;
    } elseif (strpos($service_name, 'barkada') !== false || strpos($service_name, 'family') !== false) {
        $calendar_data['FL-1'][] = $b;
    }
}

// 5. Function to calculate position (10 AM to 11 PM)
function getTimePosition($start_time, $end_time) {
    $base_time = strtotime('10:00:00'); 
    $start = strtotime($start_time);
    $end = strtotime($end_time);
    $total_minutes = 780; // 13 hours
    
    $start_mins = ($start - $base_time) / 60;
    $duration_mins = ($end - $start) / 60;
    
    $left_pct = ($start_mins / $total_minutes) * 100;
    $width_pct = ($duration_mins / $total_minutes) * 100;
    
    if ($start_mins < 0 || $start_mins > $total_minutes) {
        return "display: none;";
    }
    
    return "left: " . $left_pct . "%; width: " . $width_pct . "%;";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard | Admin</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/png" href="logo.png">
</head>
<body>
    <div class="admin-layout">
        <!-- SIDEBAR -->
                <div class="sidebar">
            <div style="display:flex; align-items:center; color:#FBF7F0; margin-bottom:30px;">
                <img src="logo.png" alt="Logo" style="width: 35px; height: 35px; object-fit: contain; margin-right: 10px;">
                <h2 style="margin: 0;">Admin</h2>
            </div>
            <a href="admin.php" class="<?= basename($_SERVER['PHP_SELF']) == 'admin.php' ? 'active' : '' ?>">Dashboard</a>
            <a href="admin_all_bookings.php" class="<?= basename($_SERVER['PHP_SELF']) == 'admin_all_bookings.php' ? 'active' : '' ?>">All Bookings</a>
            <a href="admin_new.php" class="<?= basename($_SERVER['PHP_SELF']) == 'admin_new.php' ? 'active' : '' ?>">New Reservation</a>
            <a href="admin_therapists.php" class="<?= basename($_SERVER['PHP_SELF']) == 'admin_therapists.php' ? 'active' : '' ?>">Therapists</a>
            <a href="logout.php" onclick="return confirm('Are you sure you want to log out of the Admin Portal?');">Sign out</a>
        </div>

        <div class="main-content admin-main-bg">
            <!-- TOP BANNER -->
            <div style="background-color: #3B2A20; border-radius: 10px; padding: 20px 30px; display: flex; align-items: center; margin-bottom: 40px; box-shadow: 0 4px 10px rgba(0,0,0,0.1);">
                <img src="logo.png" alt="Logo" style="width: 45px; height: 45px; object-fit: contain; margin-right: 15px;">
                <div>
                    <h2 style="color: #FBF7F0; font-size: 24px; margin: 0; font-family: 'Cormorant Garamond', serif;">Bella Vista Oasis Spa</h2>
                    <p style="color: #D9BFA3; font-size: 13px; margin: 5px 0 0 0;">Front desk dashboard · Open daily 10:00 AM to 11:00 PM</p>
                </div>
            </div>

            <?php if($error_message): ?>
                <div style="background: #f8d7da; color: #721c24; padding: 15px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #f5c6cb;">
                    <strong>Error:</strong> <?= $error_message ?>
                </div>
            <?php endif; ?>
            
            <?php if(isset($_GET['success'])): ?>
                <div style="background: #d4edda; color: #155724; padding: 15px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #c3e6cb;">
                    <strong>Success!</strong> Therapist has been assigned.
                </div>
            <?php endif; ?>

            <!-- STAT CARDS -->
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 25px; margin-bottom: 50px;">
                <div style="background: linear-gradient(135deg, #F9E8C9 0%, #F3E9DA 100%); padding: 30px; border-radius: 15px; box-shadow: 0 5px 15px rgba(59, 42, 32, 0.05); border: 1px solid #EAD5B8;">
                    <p style="font-size: 15px; color: #6F4E37; margin-bottom: 15px;">Bookings on this date</p>
                    <h2 style="font-size: 36px; color: #3B2A20; margin: 0; font-family: 'Cormorant Garamond', serif;"><?= count($bookings) ?></h2>
                </div>
                <div style="background: linear-gradient(135deg, #F9E8C9 0%, #F3E9DA 100%); padding: 30px; border-radius: 15px; box-shadow: 0 5px 15px rgba(59, 42, 32, 0.05); border: 1px solid #EAD5B8;">
                    <p style="font-size: 15px; color: #6F4E37; margin-bottom: 15px;">Active sessions</p>
                    <h2 style="font-size: 36px; color: #3B2A20; margin: 0; font-family: 'Cormorant Garamond', serif;">
                        <?php 
                            $active_count = 0;
                            $current_time = date('H:i:s');
                            foreach($bookings as $b) {
                                if ($current_time >= $b['start_time'] && $current_time <= $b['end_time'] && $b['booking_date'] == date('Y-m-d')) $active_count++;
                            }
                            echo $active_count;
                        ?>
                    </h2>
                </div>
                <div style="background: linear-gradient(135deg, #F9E8C9 0%, #F3E9DA 100%); padding: 30px; border-radius: 15px; box-shadow: 0 5px 15px rgba(59, 42, 32, 0.05); border: 1px solid #EAD5B8;">
                    <p style="font-size: 15px; color: #6F4E37; margin-bottom: 15px;">Revenue on this date</p>
                    <h2 style="font-size: 36px; color: #3B2A20; margin: 0; font-family: 'Cormorant Garamond', serif;">₱<?= number_format(array_sum(array_column($bookings, 'total_price')), 2) ?></h2>
                </div>
            </div>
            
            <!-- DATE FILTER FORM -->
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <div>
                    <h2 style="font-size: 32px; color: #3B2A20; margin: 0; font-family: 'Cormorant Garamond', serif;">Appointment Calendar</h2>
                    <p style="color: #6F4E37; font-size: 15px; margin-top: 5px;">
                        Showing schedule for: <strong style="color: #3B2A20;"><?= date('F d, Y', strtotime($filter_date)) ?></strong>
                    </p>
                </div>
                
                <form method="GET" style="display: flex; gap: 10px; align-items: center; background: #F3E9DA; padding: 10px 20px; border-radius: 10px; border: 1px solid #D9BFA3;">
                    <label style="font-family: 'Jost', sans-serif; color: #45270E; font-weight: 600;">Filter Date:</label>
                    <input type="date" name="filter_date" value="<?= htmlspecialchars($filter_date) ?>" style="padding: 8px; border: 1px solid #D9BFA3; border-radius: 6px; background: #FBF7F0; font-family: 'Jost', sans-serif;">
                    <button type="submit" class="btn" style="padding: 8px 15px; background: #6F4E37; color: #FBF7F0; font-size: 14px;">View</button>
                </form>
            </div>

            <!-- VISUAL APPOINTMENT CALENDAR -->
            <div style="background: #FBF7F0; padding: 30px; border-radius: 15px; margin-bottom: 30px; overflow-x: auto; border: 1px solid #D9BFA3;">
                
                <!-- TIME HEADERS -->
                <div style="position: relative; height: 30px; margin-bottom: 15px; margin-left: 80px; border-bottom: 1px solid #D9BFA3;">
                    <?php for($i = 10; $i <= 22; $i++): ?>
                        <?php 
                            $pos = (($i - 10) / 13) * 100;
                            $time_label = date("g A", strtotime("$i:00"));
                        ?>
                        <div style="position: absolute; left: <?= $pos ?>%; top: 0; font-size: 12px; color: #6F4E37; transform: translateX(-50%);"><?= $time_label ?></div>
                    <?php endfor; ?>
                </div>

                <!-- ROOM ROWS -->
                <div style="display: flex; flex-direction: column; gap: 15px;">
                    <?php 
                    $rooms = ['SR-1' => 'Single Room', 'CS-1' => 'Couples Suite', 'FL-1' => 'Family Lounge'];
                    foreach($rooms as $room_code => $room_name): 
                    ?>
                    <div style="display: flex; align-items: center; height: 45px;">
                        <div style="width: 80px; font-weight: 500; color: #3B2A20; font-size: 14px; flex-shrink: 0;"><?= $room_code ?></div>
                        
                        <!-- Timeline Area -->
                        <div style="position: relative; flex-grow: 1; height: 100%; background: #FBF7F0; border: 1px solid #D9BFA3; border-radius: 6px; overflow: hidden;">
                            
                            <!-- Grid Lines -->
                            <?php for($i = 1; $i < 13; $i++): ?>
                                <div style="position: absolute; left: <?= ($i/13)*100 ?>%; top: 0; bottom: 0; width: 1px; background: #F3E9DA;"></div>
                            <?php endfor; ?>

                            <!-- Render Blocks -->
                            <?php if(isset($calendar_data[$room_code])): ?>
                                <?php foreach($calendar_data[$room_code] as $booking): ?>
                                    <?php 
                                        $currentTime = date('H:i:s');
                                        // Check if active AND if the booking is for today
                                        $is_active = ($currentTime >= $booking['start_time'] && $currentTime <= $booking['end_time'] && $booking['booking_date'] == date('Y-m-d'));
                                        $bg_color = $is_active ? '#A9744F' : '#6F4E37'; 
                                        $position_style = getTimePosition($booking['start_time'], $booking['end_time']);
                                        
                                        $base_time = strtotime('10:00:00'); 
                                        $end = strtotime($booking['end_time']);
                                        $gap_mins = ($end - $base_time) / 60;
                                        $gap_left_pct = ($gap_mins / 780) * 100;
                                    ?>
                                    
                                    <!-- Booking Block -->
                                    <div style="position: absolute; top: 2px; bottom: 2px; <?= $position_style ?> background: <?= $bg_color ?>; color: #fff; border: 1px solid #FBF7F0; border-radius: 4px; font-size: 11px; padding: 5px; z-index: 2; overflow: hidden; white-space: nowrap; cursor: pointer;" title="<?= htmlspecialchars($booking['guest_name']) ?> (<?= date('g:i A', strtotime($booking['start_time'])) ?> - <?= date('g:i A', strtotime($booking['end_time'])) ?>)">
                                        <?= $is_active ? 'Active' : 'Booked' ?>
                                    </div>

                                    <!-- Cleaning Gap -->
                                    <?php if($gap_left_pct >= 0 && $gap_left_pct <= 100): ?>
                                        <div style="position: absolute; top: 2px; bottom: 2px; left: <?= $gap_left_pct ?>%; width: 3.84%; background: #D9BFA3; z-index: 1;"></div>
                                    <?php endif; ?>
                                    
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <!-- LEGEND -->
                <div style="margin-top: 25px; display: flex; gap: 20px; font-size: 13px; color: #6F4E37; border-top: 1px solid #D9BFA3; padding-top: 15px;">
                    <div style="display: flex; align-items: center; gap: 8px;"><div style="width: 15px; height: 15px; background: #6F4E37; border-radius: 3px;"></div> Booked</div>
                    <div style="display: flex; align-items: center; gap: 8px;"><div style="width: 15px; height: 15px; background: #A9744F; border-radius: 3px;"></div> Active session</div>
                    <div style="display: flex; align-items: center; gap: 8px;"><div style="width: 15px; height: 15px; background: #D9BFA3; border-radius: 3px;"></div> 30-minute cleaning gap</div>
                </div>
            </div>

            <!-- APPOINTMENT TABLE -->
            <div style="background: #F3E9DA; padding: 20px; border-radius: 15px; margin-top: 20px; overflow-x:auto;">
                <h3 style="margin-bottom: 15px; color: #3B2A20;">Bookings for <?= date('M d, Y', strtotime($filter_date)) ?></h3>
                <table style="width: 100%; border-collapse: collapse; text-align: left;">
                    <tr style="border-bottom: 1px solid #D9BFA3;">
                        <th style="padding: 15px 10px;">Ref</th>
                        <th style="padding: 15px 10px;">Guest</th>
                        <th style="padding: 15px 10px;">Service</th>
                        <th style="padding: 15px 10px;">Time</th>
                        <th style="padding: 15px 10px;">Total</th>
                        <th style="padding: 15px 10px;">Assign Therapist</th>
                    </tr>

                    <?php foreach($bookings as $b): ?>
                    <tr style="border-bottom: 1px solid #D9BFA3;">
                        <td style="padding: 15px 10px; white-space: nowrap;"><?= $b['reference_no'] ?></td>
                        <td style="padding: 15px 10px;">
                            <strong><?= htmlspecialchars($b['guest_name'] ?? 'N/A') ?></strong><br>
                            <span style="font-size: 12px; color: #6F4E37;"><?= htmlspecialchars($b['mobile'] ?? '') ?></span>
                        </td>
                        <td style="padding: 15px 10px; width: 20%;">
                            <?= $b['service_name'] ?>
                            <?php if(!empty($b['massage_details'])): ?><br><span style="font-size: 12px; color: #A9744F;"><i><?= htmlspecialchars($b['massage_details']) ?></i></span><?php endif; ?>
                        </td>
                        <td style="padding: 15px 10px; white-space: nowrap;"><?= date('g:i A', strtotime($b['start_time'])) ?> - <?= date('g:i A', strtotime($b['end_time'])) ?></td>
                        <td style="padding: 15px 10px; white-space: nowrap;">₱<?= number_format($b['total_price'],2) ?></td>
                        <td style="padding: 15px 10px;">
                            <form method="POST" style="display:flex; gap:5px; align-items:center;">
                                <input type="hidden" name="booking_id" value="<?= $b['id'] ?>">
                                <input type="hidden" name="booking_date" value="<?= $b['booking_date'] ?>">
                                <input type="hidden" name="start_time" value="<?= $b['start_time'] ?>">
                                <input type="hidden" name="end_time" value="<?= $b['end_time'] ?>">
                                <select name="therapist" style="padding: 8px; border-radius: 5px; border: 1px solid #D9BFA3; font-family: 'Jost', sans-serif; font-size: 14px;" required>
                                    <option value="">Select...</option>
                                    <option value="Maria Santos" <?= $b['therapist'] == 'Maria Santos' ? 'selected' : '' ?>>Maria Santos</option>
                                    <option value="John Doe" <?= $b['therapist'] == 'John Doe' ? 'selected' : '' ?>>John Doe</option>
                                    <option value="Jane Smith" <?= $b['therapist'] == 'Jane Smith' ? 'selected' : '' ?>>Jane Smith</option>
                                </select>
                                <button type="submit" name="assign_therapist" class="btn" style="padding: 8px 12px; font-size: 14px;">Assign</button>
                            </form>
                            <?php if($b['therapist']): ?>
                                <div style="font-size: 12px; margin-top: 8px; color: #6F4E37;"><strong>Assigned:</strong> <?= $b['therapist'] ?></div>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($bookings)): ?><tr><td colspan="6" style="padding:30px; text-align:center;">No bookings found for this date.</td></tr><?php endif; ?>
                </table>
            </div>
        </div>
    </div>
</body>
</html>