<?php
session_start();
require 'db.php';

$error = "";

if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    if ($_SESSION['staff_role'] == 'therapist') {
        header("Location: therapist_dashboard.php");
    } else {
        header("Location: admin.php");
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND role IN ('admin', 'receptionist', 'therapist')");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['staff_role'] = $user['role'];
        $_SESSION['staff_name'] = $user['name'];
        
        if ($user['role'] == 'therapist') {
            header("Location: therapist_dashboard.php");
        } else {
            header("Location: admin.php");
        }
        exit;
    } else {
        $error = "Incorrect email or password. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Staff Portal | Bella Vista</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/png" href="logo.png">
    <style>
        body { background: #F3E9DA; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; font-family: 'Jost', sans-serif; }
        .login-wrapper { display: flex; background: #FBF7F0; border-radius: 20px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1); width: 800px; max-width: 90%; min-height: 500px; }
        .login-left { background: #3B2A20; color: #FBF7F0; padding: 50px; width: 45%; display: flex; flex-direction: column; justify-content: center; }
        .login-left img { width: 80px; margin-bottom: 20px; object-fit: contain; }
        .login-left h2 { font-size: 32px; margin-bottom: 15px; font-family: 'Cormorant Garamond', serif; }
        .login-right { padding: 50px; width: 55%; display: flex; flex-direction: column; justify-content: center; }
        .login-right h2 { font-size: 28px; margin-bottom: 20px; color: #3B2A20; font-family: 'Cormorant Garamond', serif; }
        .error-msg { background: #F3E9DA; border: 1px solid #A9744F; padding: 10px; border-radius: 5px; font-size: 13px; margin-bottom: 20px; color: #3B2A20; }
        .form-group label { color: #45270E; font-weight: 500; }
        .form-group input { background: #f5e5cf; width: 100%; padding: 12px; border: 1px solid #D9BFA3; border-radius: 8px; box-sizing: border-box; font-family: 'Jost', sans-serif;}
    </style>
</head>
<body>

    <div class="login-wrapper">
        <div class="login-left">
            <img src="logo3.png" alt="Logo">
            <h2>Staff Portal</h2>
            <p style="font-size: 14px; line-height: 1.6; color: #D9BFA3;">
                Authorized spa managers, receptionists, and therapists only. All sign-ins are recorded in the activity log.
            </p>
        </div>
        <div class="login-right">
            <h2>Sign in</h2>
            
            <?php if($error): ?>
                <div class="error-msg"><?= $error ?></div>
            <?php endif; ?>

            <?php if(isset($_GET['registered'])): ?>
                <div style="background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin-bottom: 20px; text-align: center; font-size: 13px;">
                    Account created successfully! Please log in.
                </div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-group">
                    <label>Staff Email</label>
                    <!-- HTML5 type="email" forces the user to type a valid email format (user@domain.com) -->
                    <input type="email" name="email" required placeholder="staff@bellavista.com">
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" required placeholder="••••••••">
                </div>
                <button type="submit" class="btn" style="width: 100%; margin-top: 10px; background: #6F4E37; color: #FBF7F0; padding: 12px;">Sign in</button>
            </form>
            
            <div style="text-align: center; margin-top: 20px;">
                <a href="staff_register.php" style="color: #A9744F; font-size: 14px; text-decoration: underline;">Create a Staff Account</a>
            </div>
            <hr style="border: none; border-top: 1px solid #D9BFA3; margin: 20px 0;">
            <p style="font-size: 12px; color: #6F4E37; text-align: center;">
                <a href="index.php" style="color: #3B2A20; text-decoration: underline;">Back to public site</a>
            </p>
        </div>
    </div>
</body>
</html>