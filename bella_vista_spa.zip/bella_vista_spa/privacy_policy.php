<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Privacy Policy | Bella Vista Oasis Spa</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/png" href="logo.png">
    <style>
        .policy-container { max-width: 800px; margin: 100px auto; background: radial-gradient(circle, #F9E8C9 0%, #D8A45F 100%); padding: 50px; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); border: 1px solid #6F4E37 ; }
        .policy-container h1 { color: #3B2A20; margin-bottom: 20px; font-size: 36px; }
        .policy-container h2 { color: #45270E; margin-top: 30px; margin-bottom: 10px; font-size: 22px; }
        .policy-container p, .policy-container ul { color: #5C3E19; line-height: 1.8; margin-bottom: 15px; font-size: 16px; }
        .policy-container ul { padding-left: 20px; }
          /* ADD THIS BODY RULE TO CHANGE THE PAGE BACKGROUND */
        body::before {
            content: "";
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            
            /* REPLACE THIS URL WITH YOUR OWN IMAGE IF YOU WANT */
            background-image: url('policies_bg.png');  
            background-size: cover;
            background-position: center;
            
            /* LOW TRANSPARENCY (0.15 means 15% visible) */
            opacity: 100%; 
        }
        
    </style>
</head>
<body>
    <nav>
        <div class="logo">
            <a href="index.php" style="text-decoration:none; color: #FBF7F0; display:flex; align-items:center; font-family: 'Cormorant Garamond', serif; font-size: 26px; font-weight: 700;">
                <img src="logo.png" alt="Logo" style="width: 40px; height: 40px; object-fit: contain; margin-right: 10px;"> 
                Bella Vista Oasis Spa
            </a>
        </div>
        <div class="nav-links">
            <a href="index.php" class="btn" style="background: #6F4E37 ; color: #FBF7F0 !important;">Back to Home</a>
        </div>
    </nav>

    <div class="policy-container">
        <h1>Privacy Policy</h1>
        <p>Last updated: <?= date('F d, Y') ?></p>
        
        <p>At Bella Vista Oasis Spa, we are committed to protecting your privacy and ensuring the security of your personal information. This Privacy Policy explains how we collect, use, and safeguard your data when you visit our website or use our services.</p>

        <h2>1. Information We Collect</h2>
        <p>We may collect the following types of information when you book an appointment or create an account:</p>
        <ul>
            <li>Personal details (Name, Email address, Mobile number)</li>
            <li>Booking details (Dates, times, selected treatments)</li>
            <li>Health declarations (Medical conditions, injuries, pregnancy status)</li>
        </ul>

        <h2>2. How We Use Your Information</h2>
        <p>Your information is used strictly to provide you with our services, including:</p>
        <ul>
            <li>Confirming and managing your spa appointments.</li>
            <li>Ensuring the safety and suitability of treatments based on your health declaration.</li>
            <li>Sending reminders or updates regarding your bookings.</li>
        </ul>

        <h2>3. Data Security</h2>
        <p>We implement strict security measures to protect your personal data. Your information is stored in our secure database and is only accessible by authorized spa personnel.</p>

        <h2>4. Third-Party Sharing</h2>
        <p>We do not sell, trade, or rent your personal information to third parties. Your data is strictly confidential.</p>

        <p style="margin-top: 40px; font-style: italic;">If you have any questions about this Privacy Policy, please contact us at bellavistaos@gmail.com.</p>
    </div>
</body>
</html>