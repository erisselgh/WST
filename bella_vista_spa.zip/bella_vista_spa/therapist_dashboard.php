<?php
session_start();
date_default_timezone_set('Asia/Manila');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['staff_role'] !== 'therapist') {
    header("Location: login.php");
    exit;
}

require 'db.php';
$therapist_name = $_SESSION['staff_name'];

// Fetch only appointments assigned to this therapist
$stmt = $pdo->prepare("SELECT b.*, s.name as service_name FROM bookings b JOIN services s ON b.service_id = s.id WHERE b.therapist = ? ORDER BY b.booking_date DESC, b.start_time ASC");
$stmt->execute([$therapist_name]);
$bookings = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Therapist Dashboard</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .admin-layout { display: flex; height: 100vh; }
        .sidebar { width: 250px; background: #3B2A20; color: #FBF7F0; padding: 30px 20px; }
        .sidebar a { display: block; color: #FBF7F0; text-decoration: none; padding: 15px; margin-bottom: 10px; border-radius: 8px; }
        .sidebar a.active { background: #6F4E37; }
        .main-content { flex: 1; padding: 40px; overflow-y: auto; background: #F3E9DA; }
        .card { background: #FBF7F0; padding: 20px; border-radius: 15px; margin-bottom: 20px; border-left: 5px solid #6F4E37; }
    </style>
</head>
<body>
    <div class="admin-layout">
        <div class="sidebar">
            <h2 style="margin-bottom:30px;">Therapist Portal</h2>
            <a href="therapist_dashboard.php" class="active">My Schedule</a>
            <a href="logout.php">Sign out</a>
        </div>
        <div class="main-content">
            <h1>Welcome, <?= htmlspecialchars($therapist_name) ?></h1>
            <p style="color: #6F4E37; margin-bottom: 30px;">Here are your assigned appointments.</p>

            <?php if(empty($bookings)): ?>
                <div class="card"><p>You have no assigned appointments yet.</p></div>
            <?php else: ?>
                <?php foreach($bookings as $b): ?>
                    <div class="card">
                        <h3 style="color: #3B2A20; margin-bottom: 5px;"><?= date('F d, Y', strtotime($b['booking_date'])) ?> | <?= date('g:i A', strtotime($b['start_time'])) ?> - <?= date('g:i A', strtotime($b['end_time'])) ?></h3>
                        <p><strong>Guest:</strong> <?= htmlspecialchars($b['guest_name']) ?> (<?= htmlspecialchars($b['mobile']) ?>)</p>
                        <p><strong>Service:</strong> <?= $b['service_name'] ?> (<?= $b['massage_details'] ?>)</p>
                        <p><strong>Room:</strong> <?= $b['service_name'] == 'Single Room Massage' ? 'SR-1' : ($b['service_name'] == 'Couples Suite' ? 'CS-1' : 'FL-1') ?></p>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>