<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Safety & Security | Bella Vista Oasis Spa</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/png" href="logo.png">
    <style>
        .policy-container { max-width: 800px; margin: 100px auto; background: radial-gradient(circle, #F9E8C9 0%, #D8A45F 100%); padding: 50px; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); border: 1px solid #6F4E37 ; }
        .policy-container h1 { color: #3B2A20; margin-bottom: 20px; font-size: 36px; }
        .policy-container h2 { color: #45270E; margin-top: 30px; margin-bottom: 10px; font-size: 22px; }
        .policy-container p, .policy-container ul { color: #5C3E19; line-height: 1.8; margin-bottom: 15px; font-size: 16px; }
        .policy-container ul { padding-left: 20px; }
          /* ADD THIS BODY RULE TO CHANGE THE PAGE BACKGROUND */
        body::before {
            content: "";
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            
            /* REPLACE THIS URL WITH YOUR OWN IMAGE IF YOU WANT */
            background-image: url('policies_bg.png');  
            background-size: cover;
            background-position: center;
            
            /* LOW TRANSPARENCY (0.15 means 15% visible) */
            opacity: 100%; 
        }
    </style>
</head>
<body>
    <nav>
        <div class="logo">
            <a href="index.php" style="text-decoration:none; color: #FBF7F0; display:flex; align-items:center; font-family: 'Cormorant Garamond', serif; font-size: 26px; font-weight: 700;">
                <img src="logo.png" alt="Logo" style="width: 40px; height: 40px; object-fit: contain; margin-right: 10px;"> 
                Bella Vista Oasis Spa
            </a>
        </div>
        <div class="nav-links">
            <a href="index.php" class="btn" style="background: #6F4E37 ; color: #FBF7F0 !important;">Back to Home</a>
        </div>
    </nav>

    <div class="policy-container">
        <h1>Safety & Security</h1>
        <p>Last updated: <?= date('F d, Y') ?></p>
        
        <p>Your safety and well-being are our top priorities at Bella Vista Oasis Spa. We have implemented comprehensive protocols to ensure a secure and relaxing environment for all our guests.</p>

        <h2>1. Hygiene & Sanitization</h2>
        <ul>
            <li>All massage beds, linens, and towels are thoroughly cleaned and replaced after every session.</li>
            <li>A mandatory 30-minute sanitation gap is observed between bookings.</li>
            <li>Our therapists strictly adhere to personal hygiene and hand-washing protocols.</li>
        </ul>

        <h2>2. On-Site Security</h2>
        <ul>
            <li>The spa premises are monitored by 24/7 security personnel.</li>
            <li>Secure lockers are provided for guests to store personal belongings during their session.</li>
            <li>Our staff is trained to handle emergency situations, and first-aid kits are readily available.</li>
        </ul>

        <h2>3. Therapist Safety</h2>
        <p>All our therapists are certified professionals. We maintain strict boundaries and professional conduct at all times to ensure a safe environment for both guests and staff.</p>
    </div>
</body>
</html>