<?php
session_start();
session_unset();
session_destroy();
header("Location: login.php?logout=1"); // Redirect to admin login page
exit;
?>